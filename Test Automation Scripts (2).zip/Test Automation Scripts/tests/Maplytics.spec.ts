import { test, expect, Page } from '@playwright/test';
import { locatorShortcuts, LoginAccess } from '../Utils/commonVars.ts';
import { changeView, openSiteMap, saveRecord, searchRecord, startTest } from '../Utils/GeneralFunctions.ts';

////////////////////////////// MATT-14571 //////////////////////////////
var mapWindow: any;
const tomorrow = new Date();
tomorrow.setDate(tomorrow.getDate() + 1);
const tripname ="Playwright-QA Regression Test"+ tomorrow.toString();
async function addLocation(page: Page, direction: string){
  await mapWindow.getByRole('searchbox', { name: 'Search Record or Location' }).click();
  await mapWindow.getByRole('searchbox', { name: 'Search Record or Location' }).fill(direction);
  await mapWindow.locator('//ul[@class="ui-autocomplete ui-front ui-menu ui-widget ui-widget-content"]/li').nth(2).click();
  await page.waitForTimeout(4000);
  await mapWindow.locator('canvas').nth(1).click({
    position: {
      x: 708,
      y: 515
    }, button: 'right'
  });
  await mapWindow.getByRole('menuitem', { name: 'Add to Route' }).click();
  await page.waitForTimeout(2000);
}

test('Maplytics Route - Creating a trip through maplytics', async ({ page }) => {
  console.log('Testing if the creation of a route (Trip) automatically links it with Agency Visits and Meetings...');
  // Calculate tomorrow's date

  await startTest(page, 160000);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Maplytics', { exact: true }).click();
  await page.waitForTimeout(8000);
   
  // Create a route with 2 stops
  console.log('Add Producer Code Locations and POI to Route...');
  mapWindow = await page.locator('iframe[name="ikl_/Maplytics/Maplytics.DetailMap.html"]').contentFrame();
  await page.locator('iframe[name="ikl_/Maplytics/Maplytics.DetailMap.html"]').contentFrame().getByRole('link', { name: 'Plot entity records on the map' }).click();
  await page.locator('iframe[name="ikl_/Maplytics/Maplytics.DetailMap.html"]').contentFrame().locator('#txtCurrentLocation').click();
  await page.locator('iframe[name="ikl_/Maplytics/Maplytics.DetailMap.html"]').contentFrame().locator('#txtCurrentLocation').fill('Houston, Texas, United States');
  await page.locator('iframe[name="ikl_/Maplytics/Maplytics.DetailMap.html"]').contentFrame().locator('#txtCurrentLocation').click();
  await page.waitForTimeout(2000);
  await page.locator('iframe[name="ikl_/Maplytics/Maplytics.DetailMap.html"]').contentFrame().getByRole('textbox', { name: 'Please enter comma separated' }).click();
  await page.locator('iframe[name="ikl_/Maplytics/Maplytics.DetailMap.html"]').contentFrame().getByRole('textbox', { name: 'Please enter comma separated' }).fill('20');
  await page.waitForTimeout(2000);
  await page.locator('iframe[name="ikl_/Maplytics/Maplytics.DetailMap.html"]').contentFrame().locator('#selectEntity_0').selectOption('wrb_producercode');
  await page.locator('iframe[name="ikl_/Maplytics/Maplytics.DetailMap.html"]').contentFrame().locator('#viewselectEntity_0').selectOption('85a8c473-74b5-42c9-8777-558960a77938');
  await page.waitForTimeout(2000);
  await page.locator('iframe[name="ikl_/Maplytics/Maplytics.DetailMap.html"]').contentFrame().getByRole('button', { name: 'Search' }).click();
  await page.waitForTimeout(10000);
  await page.locator('iframe[name="ikl_/Maplytics/Maplytics.DetailMap.html"]').contentFrame().locator('canvas').nth(1).click({
    button: 'right',
    position: {
      x: 412,
      y: 284
    }
  });
  await page.waitForTimeout(2000);
  await page.locator('iframe[name="ikl_/Maplytics/Maplytics.DetailMap.html"]').contentFrame().locator('#mapcontextmenu').getByText('Add To Route').click();
  await page.waitForTimeout(2000);
  await page.locator('iframe[name="ikl_/Maplytics/Maplytics.DetailMap.html"]').contentFrame().locator('canvas').nth(1).click({
    button: 'right',
    position: {
      x: 364,
      y: 341
    }
  });
  await page.waitForTimeout(2000);
  await page.locator('iframe[name="ikl_/Maplytics/Maplytics.DetailMap.html"]').contentFrame().locator('#mapcontextmenu').getByText('Add To Route').click();
  await page.waitForTimeout(2000);
  await page.locator('iframe[name="ikl_/Maplytics/Maplytics.DetailMap.html"]').contentFrame().getByRole('button', { name: 'Add destination' }).click();
  await page.locator('iframe[name="ikl_/Maplytics/Maplytics.DetailMap.html"]').contentFrame().getByRole('listitem').filter({ hasText: 'CAn exact match was not found' }).getByPlaceholder('To').click();
  await page.locator('iframe[name="ikl_/Maplytics/Maplytics.DetailMap.html"]').contentFrame().getByRole('listitem').filter({ hasText: 'CAn exact match was not found' }).getByPlaceholder('To').fill('1200 Louisiana Street Harris Texas USA');
  await page.waitForTimeout(2000);  
  await mapWindow.getByRole('button', { name: 'Go' }).click();
  console.log('Sucessfully Added Producer Code Locations and POI to Route...');
   // Set and save route details
  console.log('Save the Route and create a Trip...');
  await page.waitForTimeout(2000)
  await mapWindow.locator('.icon-sprite.route-icon').click();
  await mapWindow.getByRole('textbox', { name: 'Enter the route name' }).click();
  await mapWindow.getByRole('textbox', { name: 'Enter the route name' }).fill(tripname);
  await page.waitForTimeout(2000)
  await mapWindow.locator('#routedatepicker').click();
  await mapWindow.locator('#routedatepicker').fill(tomorrow.toString());
  await page.waitForTimeout(2000)
  await mapWindow.getByRole('button', { name: 'Save' }).click();
  await page.waitForTimeout(10000)
  console.log('Sucessfully Saved the Route and created a Trip:'+ tripname);
});

async function checkMeeting(page: Page, row: number){
  // Verify linked Agency Visits and Meetings
  await page.locator('//div[@data-id="dataSetRoot_Subgrid_new_2"]').filter({ hasText: 'Agency Visits' }).locator('//div[@role="row" and @row-index="' + row + '"]//div[@col-id="wrb_name"]//a[@role="link"]').click();
  await page.waitForLoadState('domcontentloaded'); 
  await expect(page.locator('//ul[@title="Agency Visit"]//div[@role="link"]')).toHaveCount(0);
  //await page.waitForTimeout(5000);
  
}

test('Maplytics Route - Check if Agency Visits and Meetings were created', async ({ page }) => {
  await startTest(page);
  await openSiteMap(page);

  // Search for route on "Trips" view and open it
  console.log('Search for Trip:'+ tripname);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Trips', { exact: true }).click();

  await page.getByRole('searchbox', { name: 'Ask about data in this table.' }).click();
  await page.getByRole('searchbox', { name: ';' }).fill(tripname);
  await page.getByRole('searchbox', { name: ';' }).press('Enter');
  await page.waitForTimeout(5000);
  //await searchRecord(page, 'Playwright-QA Regression Test', 'Apply begins with filter on', false);
  await page.getByRole('link', { name: 'Playwright-QA Regression' }).click();
  console.log('Validating if linked Agency Visits and Meetings were created by Plugin and Automation...');
  await page.waitForTimeout(5000);
  checkMeeting(page, 1);
  //checkMeeting(page, 1);
  await page.locator('//button[@title="Go back"]').click();
  console.log('Validation Successful: Linked Agency Visits and Meetings were created by Plugin and Automation...');
  
});

////////////////////////////////////////////////////////////////////////