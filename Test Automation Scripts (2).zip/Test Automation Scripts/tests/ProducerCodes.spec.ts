import { test, expect } from '@playwright/test';
import { locatorShortcuts, LoginAccess } from '../Utils/commonVars.ts';
import { advancedSearch, openSiteMap, searchRecord, startTest } from '../Utils/GeneralFunctions.ts';
import { createAccount } from './Account.spec.ts';

// Producer Code test example data
// NAME CHANGE IS PENDING WHEN CREATION AUTOMATION IS DEPLOYED
const PCName = "--"
////////////////////////////// MATT-12934 //////////////////////////////
test('Related Account - Read-Only fields', async ({ page }) => {
  console.log('Testing account fields on a producer codes record...');
  
  await startTest(page);
  await openSiteMap(page);

  // Create test account
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Accounts', { exact: true }).click();
  await createAccount(page, false, 'Playwright Producer Codes', 'Office', 'California');
  await page.getByRole('tab', { name: 'Summary' }).click();
  await page.getByRole('textbox', { name: 'Email' }).click();
  await page.getByRole('textbox', { name: 'Email' }).fill('playwright@test.com');
  await page.getByRole('textbox', { name: 'Main Phone' }).click();
  await page.getByRole('textbox', { name: 'Main Phone' }).fill('123456');
  await page.getByRole('textbox', { name: 'NPN' }).click();
  await page.getByRole('textbox', { name: 'NPN' }).fill('1234');
  await page.getByRole('textbox', { name: 'Agency Code' }).click();
  await page.getByRole('textbox', { name: 'Agency Code' }).fill('12345');
  await page.getByRole('textbox', { name: 'Description' }).click();
  await page.getByRole('textbox', { name: 'Description' }).fill('Playwright Test Description');
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();
  await openSiteMap(page);

  // Create Producer Code record
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Producer Codes', { exact: true }).click();
  await page.getByRole('menuitem', { name: 'New', exact: true }).click();
  await page.getByRole('textbox', { name: 'Description' }).click();
  await page.getByRole('textbox', { name: 'Description' }).fill('Playwright Test Producer Code');
  await page.getByRole('textbox', { name: 'Producer Code' }).click();
  await page.getByRole('textbox', { name: 'Producer Code' }).fill('Playwright Test Producer Code');
  await page.getByRole('textbox', { name: 'Legacy Code' }).click();
  await page.getByRole('textbox', { name: 'Legacy Code' }).fill('Playwright Test Legacy Code');
  await page.getByRole('button', { name: 'Search records for Account,' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Producer Codes', 'Choose account for Account');

  // Check if fields are read-only and data is consistent
  await expect(page.getByLabel('Locked Description').getByText('')).toBeVisible();
  await expect(page.getByText('Playwright Test Description')).toBeVisible();
  await expect(page.getByLabel('Locked Parent Account').getByText('')).toBeVisible();
  await expect(page.getByLabel('Locked Account Type').getByText('')).toBeVisible();
  await expect(page.getByRole('list', { name: 'Account Type' }).getByText('Office')).toBeVisible();
  await expect(page.getByLabel('Locked Agency Code').getByText('')).toBeVisible();
  await expect(page.locator('//input[@aria-label="Agency Code" and @value="12345"]')).toBeVisible();
  await expect(page.getByLabel('Locked NPN').getByText('')).toBeVisible();
  await expect(page.locator('//input[@aria-label="NPN" and @value="1234"]')).toBeVisible();
  await expect(page.getByLabel('Locked Email').getByText('')).toBeVisible();
  await expect(page.locator('//input[@aria-label="Email" and @value="playwright@test.com"]')).toBeVisible();
  await expect(page.getByLabel('Locked Main Phone').getByText('')).toBeVisible();
  await expect(page.locator('//input[@aria-label="Main Phone" and @value="123456"]')).toBeVisible();
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();

  console.log('Account fields on producer codes record are read-only and data is consistent.');
});
////////////////////////////////////////////////////////////////////////

////////////////////////////// MATT-12934 //////////////////////////////
// This tests uses the data from test "Related Account - Read-Only fields"
test('Global Search - Search by Producer Code and Legacy Code', async ({ page }) => {
  console.log('Searching a Producer Code on Global Search by Producer Code and Legacy Code...');
  
  await startTest(page);
  
  // Search by Producer Code
  await page.getByRole('searchbox', { name: 'Search' }).click();
  await page.getByRole('searchbox', { name: 'Search' }).fill('Playwright Test Producer Code');
  await page.waitForTimeout(3000);
  await expect(page.locator('//div[text()="Producer Codes"]/..//label[text()="' + PCName +'"]')).toBeVisible();

  // Search by Legacy Code
  await page.getByRole('searchbox', { name: 'Search' }).click();
  await page.getByRole('searchbox', { name: 'Search' }).fill('Playwright Test Legacy Code');
  await page.waitForTimeout(3000);
  await expect(page.locator('//div[text()="Producer Codes"]/..//label[text()="' + PCName +'"]')).toBeVisible();

  console.log('Producer Code found successfully by Producer Code and Legacy Code on Global Search.');
});
////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////
// This tests uses the data from test "Related Account - Read-Only fields"
test('Producer Codes - Remove data from previous tests', async ({ page }) => {
  console.log('Removing data from previous tests...');
  await startTest(page);

  await page.locator(locatorShortcuts.SIDEMENU).getByText('Accounts', { exact: true }).click();
  await searchRecord(page, 'Playwright Producer Codes', 'Account Filter by keyword', true);
  await page.locator('//section[@aria-label="Producer Codes"]//div[@role="rowgroup" and contains(@class, "header")]//i[@data-icon-name="CheckMark"]').click();
  await page.locator('//button[@aria-label="More commands for Producer Code"]').click();
  await page.getByRole('menuitem', { name: 'Delete Producer Code' }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();
  await page.waitForTimeout(3000);
  await page.locator('//button[@aria-label="Delete" and @role="menuitem"]').click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();

  console.log('Data from previous tests removed successfully.');
});
////////////////////////////////////////////////////////////////////////