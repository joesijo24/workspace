import { test, expect } from '@playwright/test';
import { locatorShortcuts, LoginAccess } from '../Utils/commonVars.ts';
import { advancedSearch, openSiteMap, saveRecord, searchRecord, startTest } from '../Utils/GeneralFunctions.ts';
import { createAccount } from './Account.spec.ts';

////////////////////////////// MATT-11965 //////////////////////////////
test('Sales Territories - Multiple Assignment to users', async ({ page }) => {
  console.log('Testing multiple territories assignment...');
  
  await startTest(page);
  await page.getByRole('button', { name: 'Sales (change area)' }).click();
  await page.getByText('App Settings').click();
  await page.getByRole('button', { name: 'Site Map' }).click();
  await page.waitForTimeout(4000);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Sales Territories').click();

  // Assign users to "CO" territory
  await searchRecord(page, 'CO', 'Sales Territory Filter by', true);
  await page.getByRole('menuitem', { name: 'New Territory Team Member.' }).click();
  await page.getByRole('button', { name: 'Search records for User,' }).click();
  await page.getByLabel('# Agent 365 Tools,').getByText('btsuswrbppedcrmtst01').click();
  await page.getByRole('button', { name: 'Search records for Role,' }).click();
  await page.getByRole('treeitem', { name: 'BDU Manager' }).click();
  await page.locator('//section[@data-id="quickCreateRoot"]//button[@aria-label="Save and Close"]').click();
  await page.getByRole('menuitem', { name: 'New Territory Team Member.' }).click();
  await page.getByRole('button', { name: 'Search records for User,' }).click();
  await page.getByText('# AIBuilder_StructuredML_Gcc_CDS_Legacy').click();
  await page.getByRole('button', { name: 'Search records for Role,' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'SBU Manager', 'Choose category for Role');
  await page.locator('//section[@data-id="quickCreateRoot"]//button[@aria-label="Save and Close"]').click();
  await page.getByRole('combobox', { name: 'Assignment Method' }).click();
  await page.getByRole('option', { name: 'Manual' }).click();

  // Check if users are assigned correctly
  await expect(page.locator('//div[@role="row"]').filter({hasText: '# Agent 365 Tools'}).filter({hasText: 'BDU Manager'})).toBeVisible();
  await expect(page.locator('//div[@role="row"]').filter({hasText: '# AIBuilder_StructuredML_Gcc_CDS_Legacy'}).filter({hasText: 'SBU Manager'})).toBeVisible();

  await page.getByRole('menuitem', { name: 'Save & Close' }).click();
  await page.waitForTimeout(4000);

  // Assign users to "AR" territory
  await searchRecord(page, 'AR', 'Sales Territory Filter by', true);
  await page.getByRole('menuitem', { name: 'New Territory Team Member.' }).click();
  await page.getByRole('button', { name: 'Search records for User,' }).click();
  await page.getByText('# Agent 365 Tools').click();
  await page.getByRole('button', { name: 'Search records for Role,' }).click();
  await page.getByText('Underwriting Support Leader').click();
  await page.locator('//section[@data-id="quickCreateRoot"]//button[@aria-label="Save and Close"]').click();
  await page.getByRole('menuitem', { name: 'New Territory Team Member.' }).click();
  await page.getByRole('button', { name: 'Search records for User,' }).click();
  await page.getByText('# CDSReportService-CHE').click();
  await page.getByRole('button', { name: 'Search records for Role,' }).click();
  await page.getByText('Small Business Underwriter (').click();
  await page.locator('//section[@data-id="quickCreateRoot"]//button[@aria-label="Save and Close"]').click();
  await page.waitForTimeout(4000);
  await page.getByRole('combobox', { name: 'Assignment Method' }).click();
  await page.getByRole('option', { name: 'Manual' }).click();
  // Check if users are assigned correctly
  await expect(page.locator('//div[@role="row"]').filter({hasText: '# Agent 365 Tools'}).filter({hasText: 'Underwriting Support Leader'})).toBeVisible();
  await expect(page.locator('//div[@role="row"]').filter({hasText: '# CDSReportService-CHE'}).filter({hasText: 'Small Business Underwriter (SBU)'})).toBeVisible();

  await page.getByRole('menuitem', { name: 'Save & Close' }).click();
  
  // Successful Log
  console.log('Users assigned to territories successfully.');
});

test('Sales Territories - Clean test data', async ({ page }) => {
  console.log('Removing user assignments from territories...');
  
  await startTest(page);
  await openSiteMap(page);
  await page.getByRole('button', { name: 'Sales (change area)' }).click();
  await page.getByText('App Settings').click();
  await page.getByRole('button', { name: 'Site Map' }).click();
  await page.waitForTimeout(4000);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Sales Territories').click();

  // Removing test data
  await searchRecord(page, 'CO', 'Sales Territory Filter by', true);
  await page.waitForTimeout(4000);
  await page.locator('//div[@role="row"]').filter({hasText: '# Agent 365 Tools'}).filter({hasText: 'BDU Manager'}).locator('//i[@data-icon-name="CheckMark"]').click();
  await page.locator('//div[@role="row"]').filter({hasText: '# AIBuilder_StructuredML_Gcc_CDS_Legacy'}).filter({hasText: 'SBU Manager'}).locator('//i[@data-icon-name="CheckMark"]').click();
  await page.getByRole('menuitem', { name: 'More commands for Territory' }).click();
  await page.getByLabel('Delete Territory Team Member').click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();
  await page.getByText('Sales Territories', { exact: true }).click();
  await searchRecord(page, 'AR', 'Sales Territory Filter by', true);
  await page.waitForTimeout(4000);
  await page.locator('//div[@role="row"]').filter({hasText: '# Agent 365 Tools'}).filter({hasText: 'Underwriting Support Leader'}).locator('//i[@data-icon-name="CheckMark"]').click();
  await page.locator('//div[@role="row"]').filter({hasText: '# CDSReportService-CHE'}).filter({hasText: 'Small Business Underwriter (SBU)'}).locator('//i[@data-icon-name="CheckMark"]').click();
  await page.getByRole('menuitem', { name: 'More commands for Territory' }).click();
  await page.getByLabel('Delete Territory Team Member').click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();

  console.log('Territory assignments removed successfully.');
});
////////////////////////////////////////////////////////////////////////

////////////////////////////// MATT-12942 //////////////////////////////
test('Sales Territories - Check available roles', async ({ page }) => {
  console.log('Checking available roles for users...');
  
  await startTest(page);
  await openSiteMap(page);
  await page.getByRole('button', { name: 'Sales (change area)' }).click();
  await page.getByRole('menuitemradio', { name: 'App Settings' }).click();
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Sales Territories').click();

  // Create Parent Territory
  await page.getByRole('menuitem', { name: 'New', exact: true }).click();
  await page.getByRole('textbox', { name: 'Territory Name' }).click();
  await page.getByRole('textbox', { name: 'Territory Name' }).fill('Playwright Test Parent Territory');
  await saveRecord(page);
  await page.getByRole('menuitem', { name: 'New Territory Team Member.' }).click();
  await page.getByRole('button', { name: 'Search records for Role,' }).click();
  await expect(page.locator('//div[@aria-label="Role Lookup results"]//span[text()="Distribution Executive"]')).toBeVisible();
  await expect(page.locator('//div[@aria-label="Role Lookup results"]//span[text()="BDU Manager"]')).toBeVisible();
  await expect(page.locator('//div[@aria-label="Role Lookup results"]//span[text()="SBU Manager"]')).toBeVisible();
  await expect(page.locator('//div[@aria-label="Role Lookup results"]//span[text()="Renewal Manager"]')).toBeVisible();
  await expect(page.locator('//div[@aria-label="Role Lookup results"]//span[text()="Executive Underwriter"]')).toBeVisible();
  await expect(page.locator('//div[@aria-label="Role Lookup results"]//span[text()="Underwriting Support Leader"]')).toBeVisible();
  await page.getByRole('button', { name: 'Cancel' }).click();
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();

  // Create Child Territory with Parent assigned
  await page.getByRole('menuitem', { name: 'New', exact: true }).click();
  await page.getByRole('textbox', { name: 'Territory Name' }).click();
  await page.getByRole('textbox', { name: 'Territory Name' }).fill('Playwright Test Child Territory');
  await page.getByRole('button', { name: 'Search records for Parent' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Parent Territory', 'Choose sales territory for');
  await saveRecord(page)
  await page.getByRole('menuitem', { name: 'New Territory Team Member.' }).click();
  await page.getByRole('button', { name: 'Search records for Role,' }).click();
  await expect(page.locator('//div[@aria-label="Role Lookup results"]//span[text()="Business Development Underwriter (BDU)"]')).toBeVisible();
  await expect(page.locator('//div[@aria-label="Role Lookup results"]//span[text()="Small Business Underwriter (SBU)"]')).toBeVisible();
  await expect(page.locator('//div[@aria-label="Role Lookup results"]//span[text()="Renewal Underwriter"]')).toBeVisible();
  await expect(page.locator('//div[@aria-label="Role Lookup results"]//span[text()="Underwriting Tech"]')).toBeVisible();
  await expect(page.locator('//div[@aria-label="Role Lookup results"]//span[text()="Associate Underwriter"]')).toBeVisible();
  await expect(page.locator('//div[@aria-label="Role Lookup results"]//span[text()="Marketplace Broker"]')).toBeVisible();
  await page.getByRole('button', { name: 'Cancel' }).click();
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();

  console.log('Available roles in territories verified successfully.');
});

test('Sales Territories - Remove Test Territories', async ({ page }) => {
  console.log('Checking available roles for users...');
  
  await startTest(page);
  await openSiteMap(page);
  await page.getByRole('button', { name: 'Sales (change area)' }).click();
  await page.getByRole('menuitemradio', { name: 'App Settings' }).click();
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Sales Territories').click();

  // Delete test data
  await searchRecord(page, 'Playwright Test', 'Sales Territory Filter by', false);
  await page.locator('//div[@role="row"]//div[@col-id="wrb_name"]//span[text()="Playwright Test Parent Territory"]').click();
  await page.getByRole('tab', { name: 'Related Territories' }).click();
  await page.waitForTimeout(3000);
  await page.locator('//div[@role="row"]').filter({hasText:'Playwright Test Parent Territory'}).filter({hasText:'Playwright Test Child Territory'}).locator('//i[@data-icon-name="CheckMark"]').click();
  await page.getByRole('menuitem', { name: 'Delete Sales Territory' }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();
  await page.waitForTimeout(3000);
  await page.locator('//button[@aria-label="Delete"]').click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();

  console.log('Test territories removed successfully.');
});
// PENDING CHANGES TO BE DEPLOY TO TEST ENVIRONMENT
/*
test('Sales Territories - Change user\'s role', async ({ page }) => {
  console.log('Assigning user to a territory...');
  
  await startTest(page);
  await openSiteMap(page);
  await page.getByRole('button', { name: 'Sales (change area)' }).click();
  await page.getByRole('menuitemradio', { name: 'App Settings' }).click();
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Sales Territories').click();
  await searchRecord(page, 'Playwright Test Parent Territory', 'Sales Territory Filter by', true);
  await page.getByRole('link', { name: 'Playwright Test Parent' }).click();

  await page.getByRole('menuitem', { name: 'New Territory Team Member.' }).click();
  await page.goto('https://btsuswrbppedcrmtst01.crm.dynamics.com/main.aspx?appid=601e937f-224a-f011-877a-000d3a3acdbe&pagetype=entityrecord&etn=wrb_territoryteammember');
  await page.getByText('Got it').click();
  await page.getByRole('button', { name: 'Search records for User,' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Ezequiel Carbajo', 'Choose user for User');
  await page.getByRole('button', { name: 'Search records for Role,' }).click();
  await page.getByText('Distribution Executive').click();
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();
  await page.getByRole('link', { name: 'Go to record' }).click();
  await page.getByRole('button', { name: 'Search records for Role,' }).click();
  await page.getByText('SBU Manager').click();
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();
});*/
////////////////////////////////////////////////////////////////////////
////////////////////////////// MATT-12877 //////////////////////////////

// The read-only won't be checked since it involves security configurations not practical for automated tests
test('Sales Territories - Check account\'s view for territory', async ({ page }) => {
  console.log('Checking view in account form...');
  
  await startTest(page);
  await openSiteMap(page);

  // Create a new test account with a territory assigned
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Accounts', { exact: true }).click();
  await createAccount(page, false, 'Playwright Test Account', 'Office', 'California');
  await saveRecord(page)
  await page.getByRole('tab', { name: 'Summary' }).click();
  await page.getByRole('menuitem', { name: 'More commands for Territory' }).click();
  await page.getByRole('menuitem', { name: 'New Territory Assignment. Add' }).click();
  await page.getByLabel('dismiss').click();

  await page.getByRole('button', { name: 'Search records for Territory' }).click();
  await page.getByText('CA', {exact: true}).click();
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();
  await page.waitForTimeout(3000);

  // Check if the territory is visible and correctly assigned
  await expect(page.getByRole('link', { name: 'CA', exact: true})).toBeVisible();

  // Remove test data
  await page.getByRole('menuitem', { name: 'More commands for Account' }).click();
  await page.locator('//button[@aria-label="Delete" and @role="menuitem"]').click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();
});
////////////////////////////////////////////////////////////////////////

////////////////////////////// MATT-12879 //////////////////////////////
test('Sales Territories - Check unassigned accounts view', async ({ page }) => {
  console.log('Checking view in account form...');
  
  await startTest(page);
  await openSiteMap(page);

  // Create a new test account
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Accounts').click();
  await createAccount(page, true, 'Playwright Test Account', 'Office', 'California');

  // Search for the account in the unassigned accounts view and assign a territory
  await page.locator('//span[text()="Active Accounts"]').click();
  await page.getByRole('menuitemradio', { name: 'Unassigned Accounts' }).click();
  await searchRecord(page, 'Playwright Test Account', 'Account Filter by keyword', true);
  await page.getByRole('menuitem', { name: 'More commands for Territory Assignment' }).click();
  await page.getByRole('menuitem', { name: 'New Territory Assignment. Add' }).click();
  await page.getByLabel('dismiss').click();
  await page.getByRole('button', { name: 'Search records for Territory' }).click();
  await page.getByText('AL', {exact: true}).click();
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();
  await page.waitForTimeout(3000);
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();

  // Verify that the account is no longer in the unassigned accounts view
  await page.getByRole('searchbox', { name: 'Account Filter by keyword' }).fill('Playwright Test Account');
  await page.locator('//div[@role="treegrid"]').click();
  await page.getByRole('searchbox', { name: 'Account Filter by keyword' }).press('Enter');
  await expect(page.getByRole('link', { name: 'Playwright Test Account' })).not.toBeVisible();
  await page.getByRole('button', { name: 'Unassigned Accounts*' }).click();
  await page.getByRole('menuitemradio', { name: 'Active Accounts Default' }).click();
  await searchRecord(page, 'Playwright Test Account', 'Account Filter by keyword', true);
  await page.getByRole('menuitem', { name: 'More commands for Account' }).click();
  await page.locator('//button[@aria-label="Delete" and @role="menuitem"]').click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();
});
////////////////////////////////////////////////////////////////////////

////////////////////////////// MATT-12981 //////////////////////////////

// The read-only won't be checked since it involves security configurations not practical for automated tests
test('Sales Territories - Override Strategic Accounts', async ({ page }) => {
  console.log('Checking if account assignment can be assigned...');
  
  await startTest(page);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Accounts', { exact: true }).click();
  await createAccount(page, true, 'Playwright Override Account', 'Agency', 'Texas');

  // Assign account to a territory and override
  await page.getByRole('button', { name: 'Sales (change area)' }).click();
  await page.getByText('App Settings').click();
  await page.getByText('Sales Territories').click();
  await searchRecord(page, 'CO', 'Sales Territory Filter by', true);
  await page.locator('//li[@aria-label="Related"]').click();
  await page.locator('//div[@role="menuitem"]/span[text()="Territory Assignments"]').click();
  await page.getByRole('menuitem', { name: 'New Territory Assignment. Add' }).click();
  await page.getByText('Got it').click();
  await page.getByRole('button', { name: 'Search records for Record,' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Override Account', 'Choose record for Record');
  await page.getByRole('switch', { name: 'Override: No' }).click();
  await expect(page.getByRole('switch', { name: 'Override: Yes' })).toBeVisible();
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();
  await expect(page.getByRole('link', { name: 'Playwright Override Account' })).toBeVisible();

  console.log('Account assigned to territory with override successfully.');
});

test('Sales Territories - Remove Data from MATT-12981', async ({ page }) => {
  console.log('Removing data from MATT-12981...');

  await startTest(page);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Accounts', { exact: true }).click();
  await searchRecord(page, 'Playwright Override Account', 'Account Filter by keyword', true);
  await page.locator('//button[@aria-label="Delete" and @role="menuitem"]').click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();

  console.log('Data removed successfully.');
});
////////////////////////////////////////////////////////////////////////