import { test, expect } from '@playwright/test';
import { locatorShortcuts, LoginAccess } from '../Utils/commonVars';
import { openSiteMap, searchRecord, startTest } from '../Utils/GeneralFunctions.ts';

////////////////////////////// MATT-11807 //////////////////////////////
test('Announcements Form - CRUD operations', async ({ page }) => {
  console.log('Testing Announcements CRUD operations...');
  
  await startTest(page);
  await openSiteMap(page);

  // Navigate to Announcements
  await page.getByRole('button', { name: 'Sales (change area)' }).click();
  await page.getByText('App Settings').click();
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Announcements').click();

  // Create new Announcement
  await page.getByRole('menuitem', { name: 'New', exact: true }).click();
  await page.getByRole('textbox', { name: 'Title' }).click();
  await page.getByRole('textbox', { name: 'Title' }).fill('Playwright CRUD Test');
  await page.getByRole('textbox', { name: 'Details' }).click();
  await page.getByRole('textbox', { name: 'Details' }).fill('Description Test');
  
  await page.getByRole('combobox', { name: 'Date of Start Date' }).click();
  await page.getByLabel('Date of Start Date').click();
  await page.getByRole('combobox', { name: 'Date of Start Date' }).fill('07/07/2026');
  await page.getByRole('combobox', { name: 'Date of Start Date' }).press('Enter');
  await page.getByLabel('Date of End Date').click();
  await page.getByLabel('Date of End Date').click();
  await page.getByRole('combobox', { name: 'Date of End Date' }).fill('08/08/2026');
  await page.getByRole('combobox', { name: 'Date of End Date' }).press('Enter');
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();

  // Search and view the created Announcement
  await searchRecord(page, 'Playwright CRUD Test', 'Announcement Filter by keyword', true);

  // Deactivate and Delete the created Announcement
  await page.getByRole('menuitem', { name: 'Deactivate' }).click();
  await page.getByRole('button', { name: 'Deactivate' }).click();
  await expect(page.getByText('Read-only This record’s status: Inactive', { exact: true })).toBeVisible();
  await page.getByRole('menuitem', { name: 'Delete' }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();

  console.log('Announcement CRUD operations tested successfully.');
});
////////////////////////////////////////////////////////////////////////