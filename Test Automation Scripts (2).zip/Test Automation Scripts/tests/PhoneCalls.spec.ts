import { test, expect } from '@playwright/test';
import { LoginAccess, locatorShortcuts } from '../Utils/commonVars.ts';
import { openSiteMap, advancedSearch, saveRecord, searchRecord, changeView, startTest } from '../Utils/GeneralFunctions.ts';
import { createAccount } from './Account.spec.ts';

////////////////////////////// MATT-12986 //////////////////////////////
test('Phone Calls - Reopen Closed and Completed records', async ({ page }) => {
  console.log('Testing ReOpenning function in Phone Calls...');
  await startTest(page);
  
  // Create Phone Call record
  console.log('Creating Phone Call record...');
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Activities').click();
  await page.getByRole('menuitem', { name: 'Phone Call' }).click();
  await page.getByRole('textbox', { name: 'Subject' }).click();
  await page.getByRole('textbox', { name: 'Subject' }).fill('Playwright Completed Phone Call');
  await page.getByRole('button', { name: 'Search records for Call To,' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Reserved', 'Choose records for Call To');

  await page.getByRole('button', { name: 'Search records for Regarding' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Reserved', 'Choose record for Regarding');
  await saveRecord(page);
  console.log('Phone Call record created successfully.');

  // Complete, re-open and edit Phone Call record
  await page.getByRole('menuitem', { name: 'Mark Complete' }).click();
  await changeView(page, 'My Completed Phone Calls Last 30 Days');
  await searchRecord(page, 'Playwright Completed Phone Call', 'Phone Call', true);
  await expect(page.locator('//span[text()="Read-only  This record’s status: Completed"]')).not.toHaveCount(0);
  await page.getByRole('menuitem', { name: 'Reopen' }).click();

  console.log('Editing reopened Phone Call record...');
  await page.getByRole('textbox', { name: 'Phone Number' }).click();
  await page.getByRole('textbox', { name: 'Phone Number' }).fill('123456');
  await page.locator('//label[text()="Direction"]/../..//input[@role="switch" and @type="checkbox"]').click();
  await page.getByLabel('Date of Start Date').click();
  await page.getByRole('combobox', { name: 'Date of Start Date' }).fill('2/2/2027');
  await page.getByLabel('Date of Due').click();
  await page.getByRole('combobox', { name: 'Date of Due' }).fill('3/3/2027');
  await page.getByRole('button', { name: 'Open Duration' }).click();
  await page.getByRole('option', { name: '15 minutes' }).click();
  await page.getByRole('combobox', { name: 'Priority' }).click();
  await page.getByRole('option', { name: 'Low' }).click();
  await page.getByRole('button', { name: 'Search records for Originating Record, Lookup field' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Reserved', 'Choose agency visit for');
  await page.getByRole('textbox', { name: 'Description' }).click();
  await page.getByRole('textbox', { name: 'Description' }).fill('Playwright Test');
  await saveRecord(page);

  console.log('Reopened Phone Call record edited successfully.');

  // Close Phone Call as "Canceled"
  console.log('Closing Phone Call record as Canceled...');
  await page.getByRole('menuitem', { name: 'Close Phone Call' }).click();
  await page.getByRole('combobox', { name: 'State' }).click();
  await page.getByRole('option', { name: 'Canceled' }).click();
  await page.waitForTimeout(1000);
  await page.getByRole('button', { name: 'Close Phone Call' }).click();
  await expect(page.getByText('Read-only This record’s status: Canceled', { exact: true })).toBeVisible();

  // Re-open and edit Phone Call record again
  console.log('Re-opening Phone Call record again for final edits...');
  await page.getByRole('menuitem', { name: 'Reopen' }).click();
  await page.getByRole('textbox', { name: 'Description' }).click();
  await page.getByRole('textbox', { name: 'Description' }).fill('Playwright Test Canceled');
  await page.getByRole('list', { name: 'Originating Record' }).getByLabel('Delete Playwright Test').click();
  await page.getByLabel('Date of Start Date').click();
  await page.getByRole('combobox', { name: 'Date of Start Date' }).fill('3/3/2027');
  await page.getByRole('button', { name: 'Open Time of Start Date' }).click();
  await page.getByRole('option', { name: '9:30 AM' }).click();
  await page.getByLabel('Date of Due').click();
  await page.getByRole('combobox', { name: 'Date of Due' }).fill('4/4/2027');
  await page.getByRole('button', { name: 'Open Time of Due' }).click();
  await page.getByRole('option', { name: '9:30 AM' }).click();
  await page.getByRole('button', { name: 'Open Duration' }).click();
  await page.getByRole('option', { name: '30 minutes' }).click();
  await page.getByRole('combobox', { name: 'Priority' }).click();
  await page.getByRole('option', { name: 'Normal' }).click();
  await page.getByRole('textbox', { name: 'Phone Number' }).click();
  await page.getByRole('textbox', { name: 'Phone Number' }).fill('1234567');
  await page.locator('//label[text()="Direction"]/../..//input[@role="switch" and @type="checkbox"]').click();
  await saveRecord(page);

  console.log('Final edits to reopened Phone Call record saved successfully.');

  // Remove test data
  await page.getByRole('menuitem', { name: 'Delete' }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();
});
////////////////////////////////////////////////////////////////////////