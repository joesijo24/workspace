import { test, expect } from '@playwright/test';
import { locatorShortcuts, LoginAccess } from '../Utils/commonVars.ts';
import { changeView, openSiteMap, saveRecord, searchRecord, startTest } from '../Utils/GeneralFunctions.ts';

////////////////////////////// MATT-11927 //////////////////////////////
test('LOB - Multiple Assignment to a new contact', async ({ page }) => {
  console.log('Testing multiple Lines of Business assignment to a new contact...');
  
  await startTest(page);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Contacts', { exact: true }).click();

  //Creation of new Contact
  await page.getByRole('menuitem', { name: 'New', exact: true }).click();
  await page.getByRole('textbox', { name: 'First Name' }).click();
  await page.getByRole('textbox', { name: 'First Name' }).fill('Multiple LOB');
  await page.getByRole('textbox', { name: 'Last Name' }).click();
  await page.getByRole('textbox', { name: 'Last Name' }).fill('Playwright Test');
  await page.getByRole('textbox', { name: 'Business Phone' }).click();
  await page.getByRole('textbox', { name: 'Business Phone' }).fill('123456');
  await saveRecord(page)
  await page.locator('//button[@aria-label="More commands for Line of Business"]').click();
  await page.locator('//span[text()="New Line of Business"]').click();
  await page.locator('//button[@aria-label="Search records for Line of Business , Lookup field"]').click();
  await page.getByRole('treeitem', { name: 'Auto' }).click();
  await page.locator('//button[@aria-label="Search records for Line of Business , Lookup field"]').click();
  await page.getByText('Environmental').click();
  await page.getByRole('button', { name: 'Save and Close', exact: true }).click();
  await page.locator('//button[@aria-label="More commands for Line of Business"]').click();
  await page.locator('//span[text()="New Line of Business"]').click();
  await page.locator('//button[@aria-label="Search records for Line of Business , Lookup field"]').click();
  await page.getByText('Property').click();
  await page.getByRole('button', { name: 'Save and Close', exact: true }).click();
  await saveRecord(page)

  //Check if the Lines of Business were added successfully
  await expect(page.locator('//div[@aria-label="Lines of Business Sub Grid View"]//span[text()="Environmental"]')).toBeVisible();
  await expect(page.locator('//div[@aria-label="Lines of Business Sub Grid View"]//span[text()="Property"]')).toBeVisible();

  // Successful Log
  console.log('Lines of Business assigned successfully.');
});

test('LOB - Multiple Lines of Business assigned to existing contact', async ({ page }) => {
  console.log('Testing multiple Lines of Business assignment to an existing contact...');
  
  await startTest(page);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Contacts', { exact: true }).click();
  
  await changeView(page,"Active Contacts");
  await searchRecord(page, 'Multiple LOB Playwright Test', 'Contact Filter by keyword', true);

  // Edit the existing Lines of Business
  await page.locator('//div[@role="row"]').filter({ hasText: 'Environmental' }).locator('//i[@data-icon-name="CheckMark"]').click();
  await page.getByRole('menuitem', { name: 'Edit' }).click();
  await page.getByRole('button', { name: 'Delete Environmental' }).click();
  await page.locator('//button[@aria-label="Search records for Line of Business , Lookup field"]').click();
  await page.getByText('Excess Liability').click();
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();
  await page.locator('//div[@role="row"]').filter({ hasText: 'Property' }).locator('//i[@data-icon-name="CheckMark"]').click();
  await page.getByRole('menuitem', { name: 'Deactivate' }).click();
  await page.getByRole('button', { name: 'Deactivate' }).click();

  // Checking the updates
  await expect(page.locator('//div[@role="row"]//span[text()="Excess Liability"]')).toBeVisible();
  await expect(page.getByText('Property')).toHaveCount(0);

  /*  PENDING CHECK FOR NEXT SPRINT
  // Review the Lines of Business associated view
  await page.getByRole('menuitem', { name: 'More commands for Customer LOB' }).click();
  await page.getByRole('menuitem', { name: 'See associated records. See' }).click();
  // PENDING CHECK FOR VALID INFORMATION
  await page.getByRole('button', { name: 'Customer LOB Associated View' }).click();
  await page.getByRole('option', { name: 'Inactive Customer LOBs' }).click();
  // PENDING CHECK FOR VALID INFORMATION
  await page.getByRole('button', { name: 'Inactive Customer LOBs' }).click();
  await page.getByText('Active Customer LOBs', { exact: true }).click();
  // PENDING CHECK FOR VALID INFORMATION
  */
  console.log('Contact\'s Lines of Business updated successfully.');
});

test('LOB - Clean contact test data', async ({ page }) => {
  console.log('Testing multiple Lines of Business assignment to an existing contact...');
  
  await startTest(page);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Contacts', { exact: true }).click();
  await changeView(page,"Inactive Contacts");
  await searchRecord(page, 'Multiple LOB Playwright Test', 'Contact Filter by keyword', false);

  await page.locator("//div[@aria-label='Inactive Contacts']//div[@row-index='0']//i[@data-icon-name='CheckMark']").click();
  await page.getByRole('button', { name: 'Delete', exact: true }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();
});

test('LOB - Multiple Assignment to a new account', async ({ page }) => {
  console.log('Testing multiple Lines of Business assignment to a new account...');
  
  await startTest(page);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Accounts', { exact: true }).click();

  //Creation of new Account
  await page.getByRole('menuitem', { name: 'New', exact: true }).click();
  
  await page.getByRole('textbox', { name: 'Account Name' }).click();
  await page.getByRole('textbox', { name: 'Account Name' }).fill('Multiple LOB Playwright Test');
  await page.getByRole('button', { name: 'Search records for Account' }).click();
  await page.locator('//ul[@aria-label="Lookup results"]//span[text()="Agency"]').click();

  await page.getByRole('combobox', { name: 'State, Lookup' }).click();
  await page.getByRole('combobox', { name: 'State, Lookup' }).fill('Arizona');
  await page.getByText('Arizona').click();
  await saveRecord(page)
  await page.locator('//button[@aria-label="More commands for Line of Business"]').click()
  await page.getByRole('menuitem', { name: 'New Line of Business. Add New Line of Business' }).click();
  await page.getByRole('button', { name: 'Search records for Line of Business , Lookup field' }).click();
  await page.getByText('Inland Marine').click();
  await page.getByRole('button', { name: 'Save and Close', exact: true }).click();
  await page.locator('//button[@aria-label="More commands for Line of Business"]').click()
  await page.getByRole('menuitem', { name: 'New Line of Business. Add New Line of Business' }).click();
  await page.getByRole('button', { name: 'Search records for Line of Business , Lookup field' }).click();
  await page.getByText('Property').click();
  await page.getByRole('button', { name: 'Save and Close', exact: true }).click();
  await saveRecord(page)

  //Check if the Lines of Business were added successfully
  await expect(page.locator('//span[text()="Inland Marine"]')).toBeVisible();
  await expect(page.locator('//span[text()="Property"]')).toBeVisible();

  // Successful Log
  console.log('Lines of Business assigned successfully.');
});

test('LOB - Multiple Lines of Business assigned to existing account', async ({ page }) => {
  console.log('Testing multiple Lines of Business assignment to an existing account...');
  
  await startTest(page);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Accounts', { exact: true }).click();

  await page.getByRole('searchbox', { name: 'Account ' }).click();
  await page.getByRole('searchbox', { name: 'Account ' }).fill('Multiple LOB Playwright Test');
  await page.getByRole('searchbox', { name: 'Account ' }).press('Enter');
  await page.getByRole('link', { name: 'Multiple LOB Playwright Test' }).click();

  // Edit the existing Lines of Business
  await page.waitForTimeout(3000);
    await page.locator('//div[@role="row"]').filter({ hasText: 'Inland Marine' }).locator('//i[@data-icon-name="CheckMark"]').click();
  await page.getByRole('menuitem', { name: 'Edit' }).click();
  await page.getByRole('button', { name: 'Delete Inland Marine' }).click();
  await page.waitForTimeout(3000);
  await page.getByRole('button', { name: 'Search records for Line of Business , Lookup field' }).click();
  await page.getByText('Excess Liability').click();
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();
  await page.waitForTimeout(1500);
  await page.locator('//div[@role="row"]').filter({ hasText: 'Property' }).locator('//i[@data-icon-name="CheckMark"]').click();
  await page.waitForTimeout(1500);
  await page.locator('//button[@aria-label="More commands for Line of Business"]').click();
  await page.getByRole('menuitem', { name: 'Deactivate' }).click();
  await page.getByRole('button', { name: 'Deactivate' }).click();

  // Checking the updates
  await expect(page.locator('//span[text()="Excess Liability"]')).toBeVisible();
  await expect(page.locator('//span[text()="Property"]')).toHaveCount(0);

  /*  PENDING CHECK FOR NEXT SPRINT
  // Review the Lines of Business associated view
  await page.getByRole('menuitem', { name: 'More commands for Customer LOB' }).click();
  await page.getByRole('menuitem', { name: 'See associated records. See' }).click();
  // PENDING CHECK FOR VALID INFORMATION
  await page.getByRole('button', { name: 'Customer LOB Associated View' }).click();
  await page.getByRole('option', { name: 'Inactive Customer LOBs' }).click();
  // PENDING CHECK FOR VALID INFORMATION
  await page.getByRole('button', { name: 'Inactive Customer LOBs' }).click();
  await page.getByText('Active Customer LOBs', { exact: true }).click();
  // PENDING CHECK FOR VALID INFORMATION
  */
  console.log('Account\'s Lines of Business updated successfully.');
});

test('LOB - Clean account test data', async ({ page }) => {
  console.log('Testing multiple Lines of Business assignment to an existing account...');
  
  await startTest(page);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Accounts', { exact: true }).click();
  await searchRecord(page, 'Multiple LOB Playwright Test', 'Account Filter by keyword', false);

  await page.locator("//div[@aria-label='Active Accounts']//div[@row-index='0']//i[@data-icon-name='CheckMark']").click();
  await page.getByRole('button', { name: 'Delete', exact: true }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();
});
////////////////////////////////////////////////////////////////////////