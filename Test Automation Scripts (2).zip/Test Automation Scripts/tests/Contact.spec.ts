import { test, expect, Page, Locator } from '@playwright/test';
import { locatorShortcuts, LoginAccess } from '../Utils/commonVars';
import { changeView, openSiteMap, saveRecord, searchRecord, startTest } from '../Utils/GeneralFunctions.ts';

////////////////////////////// MATT-12940 //////////////////////////////
// This tests assumes that the Contact Extension is already set on the Contact entity
test('Contact Extension - Check fields', async ({ page }) => {
  console.log('Testing multiple Lines of Business assignment to an existing account...');

  await startTest(page);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Contacts').click();
  await changeView(page, 'Active Contacts');
  await searchRecord(page, 'Playwright Test Extension', 'Contact Filter by keyword', true);

  await page.getByRole('tab', { name: 'OU-Specific' }).click();
  await page.getByRole('button', { name: 'Search records for Focus,' }).click();
  await expect(page.locator('//div[@aria-label="Focus Lookup results"]//span[text()="Large Business"]')).toBeVisible();
  await expect(page.locator('//div[@aria-label="Focus Lookup results"]//span[text()="Middle Market"]')).toBeVisible();
  await expect(page.locator('//div[@aria-label="Focus Lookup results"]//span[text()="Small Business"]')).toBeVisible();
  await page.getByText('Focus').click();
  await page.locator('//input[contains(@aria-label, "VIP")]').click();
  await page.getByRole('textbox', { name: 'Rich Text Editor Control' }).click();
  await page.getByRole('textbox', { name: 'Rich Text Editor Control' }).fill('Test notes');
  await page.getByRole('textbox', { name: 'Street 1' }).click();
  await page.getByRole('textbox', { name: 'Street 1' }).fill('Test Street');
  await page.getByRole('textbox', { name: 'Street 2' }).click();
  await page.getByRole('textbox', { name: 'Street 2' }).fill('Street 2');
  await page.getByRole('textbox', { name: 'City' }).click();
  await page.getByRole('textbox', { name: 'City' }).fill('New York');
  if(await page.locator('//button[@aria-label="Delete California"]').count() > 0){
    await page.locator('//button[@aria-label="Delete California"]').click();
  }
  await page.getByRole('combobox', { name: 'State, Lookup' }).click();
  await page.getByRole('combobox', { name: 'State, Lookup' }).fill('California');
  await page.locator('//div[@aria-label="Dropdown panel"]//span[text()="California"]').first().click();
  await page.locator('//label[text()="Zip Code"]').click();
  await page.getByRole('textbox', { name: 'Zip Code' }).click();
  await page.getByRole('textbox', { name: 'Zip Code' }).fill('123456');
  await saveRecord(page);

  await page.getByRole('button', { name: 'Delete California' }).click();
  await saveRecord(page);
});
////////////////////////////////////////////////////////////////////////

////////////////////////////// MATT-10381 //////////////////////////////
// PNP field cannot be set through Dynamics 365 yet, so the contact was previously created with this field set
// Data: First Name: "Playwright Search", Last Name: "NPN", Email: "playwright@test.com", NPN: "1234"
test('Contact Search - Name, Email or NPN', async ({ page }) => {
  console.log('Testing Contact Search by Name, Email or NPN...');

  await startTest(page);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Contacts').click();
  await changeView(page, 'Active Contacts');

  // Search by Name
  await searchRecord(page, 'Playwright Search NPN', 'Contact Filter by keyword', false);
  await expect(page.locator('//span[text()="Playwright Search NPN"]')).toBeVisible();
  
  // Search by Email
  await page.locator('//i[@data-icon-name="Clear"]').click(); // Clear previous search
  await page.getByRole('searchbox', { name: 'Contact Filter by keyword' }).blur();
  await searchRecord(page, 'playwright@test.com', 'Contact Filter by keyword', false);
  await expect(page.locator('//span[text()="Playwright Search NPN"]')).toBeVisible();
  
  // Search by NPN
  await page.locator('//i[@data-icon-name="Clear"]').click(); // Clear previous search
  await page.getByRole('searchbox', { name: 'Contact Filter by keyword' }).blur();
  await searchRecord(page, '1234', 'Contact Filter by keyword', false);
  await expect(page.locator('//span[text()="Playwright Search NPN"]')).toBeVisible();

  console.log('Contact Search by Name, Email or NPN completed successfully');
});
////////////////////////////////////////////////////////////////////////

////////////////////////////// MATT-13255 //////////////////////////////
async function uploadAndScanCard(page: Page, fileName: string, firstName: string, lastName: string, jobTitle: string, companyName: string, email: string, businessPhone: string, mobilePhone: string, city: string, state: string) {
  // Upload Business Card
  await page.locator('//div[@data-id="businesscard-FieldSectionItemContainer"]//input[@type="file"]').setInputFiles(`./Attachments/Business Cards/${fileName}`);

  // Wait for upload to complete
  await page.waitForTimeout(2000);
  await page.locator('//div[@data-id="businesscard-FieldSectionItemContainer"]//div[contains(@class,"Spinner-circle")]').waitFor({ state: 'detached' });

  // Check that fields are populated correctly
  await expect(page.getByRole('textbox', { name: 'First Name' })).toHaveValue(firstName);
  await expect(page.getByRole('textbox', { name: 'Last Name' })).toHaveValue(lastName);
  await expect(page.getByRole('textbox', { name: 'Job Title' })).toHaveValue(jobTitle);
  await expect(page.getByRole('textbox', { name: 'Email' })).toHaveValue(email);
  await expect(page.getByRole('textbox', { name: 'Business Phone' })).toHaveValue(businessPhone);
  await expect(page.getByRole('textbox', { name: 'Mobile Phone' })).toHaveValue(mobilePhone);
  await expect(page.getByRole('textbox', { name: 'City' })).toHaveValue(city);
}

async function setOfBusinessCardTests(page: Page) {
  await uploadAndScanCard(page, 'Business Card 4.png', 'GILBERT', 'OROZCO', 'Wholesale Director', 'Imperial PFS®', 'gilbert.orozco@ipfs.com', '210.906.4937', '', 'Dallas', 'TX');
  await uploadAndScanCard(page, 'Business Card 5.png', 'JOSH', 'LARICCIA', 'CHIEF MARKETING OFFICER', 'first insurance & risk management', 'josh.lariccia@myfirstinsurance.com', '+1 619 823 2229', '', 'San Diego', 'CA');
  await uploadAndScanCard(page, 'Business Card 10.png', 'JOHN H.', 'DAWSON', 'CHIEF FINANCIAL OFFICER', '', 'JDAWSON@CORRELLINSURANCE.COM', '864 583 5445', '859 948 3580', 'SPARTANBURG', 'SOUTH CAROLINA');
  await uploadAndScanCard(page, 'Business Card 11.png', 'Teresa', 'Boyd', 'Chief Marketing Officer', 'HUB International Florida', 'teresa.boyd@hubinternational.com', '407-893-3863', '615-415-8119', 'Winter Park', 'FL');
}

test('Contact - Business Card Scanner', async ({ page }) => {
  console.log('Testing Business Card Scanner through Contact Quick Create form...');

  // Go to Contact Quick Create form
  await startTest(page);
  let tabVisible = await page.locator("//ul[@data-id='quickCreateLauncher']//button[@aria-label='Contact']").isVisible();
  while(!tabVisible){
    await page.locator("//button[@aria-label='Create New Record. New']").click();
    await page.waitForTimeout(2000);
    tabVisible = await page.locator("//ul[@data-id='quickCreateLauncher']//button[@aria-label='Contact']").isVisible();
  }
  await page.getByRole('menuitem', { name: 'Contact', exact: true }).click();

  // Test scanner with different business cards
  await setOfBusinessCardTests(page);

  // Go to account record "Contacts" tab and create a new contact
  console.log('Testing Business Card Scanner through Account record...');

  await page.getByRole('button', { name: 'Cancel' }).click();
  await page.getByRole('button', { name: 'Discard changes' }).click();
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Accounts').click();
  await searchRecord(page, 'Playwright Test Reserved', 'Account Filter by keyword', true);
  await page.getByRole('tab', { name: 'Contacts' }).click();
  await page.getByRole('menuitem', { name: 'New Contact. Add New Contact' }).click();

  // Test scanner with different business cards
  await setOfBusinessCardTests(page);
});
////////////////////////////////////////////////////////////////////////
/*
////////////////////////////// MATT-13258 //////////////////////////////
// This tests requires the contact "Playwright Test Reserved" to have the proper data on the Address tab
test('Contact Extension - Check auto-fill address fields', async ({ page }) => {
  console.log('Checking if Contact Extension address fields auto-fill from Contact address...');

  await startTest(page);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Contacts').click();
  await changeView(page, 'Active Contacts');
  await searchRecord(page, 'Playwright Test Reserved', 'Contact Filter by keyword', true);
  await page.getByRole('tab', { name: 'OU-Specific' }).click();

  // Check if fields autocomplete using Contact Address
  await expect(page.getByRole('textbox', { name: 'Street 1' })).toHaveValue('1373 Post St');
  await expect(page.getByRole('textbox', { name: 'City' })).toHaveValue('San Francisco');
  await expect(page.getByRole('textbox', { name: 'State' })).toHaveValue('California');
  await expect(page.getByRole('textbox', { name: 'Zip Code' })).toHaveValue('CA 94109');

  // Empty address fields and save
  await page.getByRole('textbox', { name: 'Street 1' }).click();
  await page.getByRole('textbox', { name: 'Street 1' }).press('ControlOrMeta+a');
  await page.getByRole('textbox', { name: 'Street 1' }).fill('');
  await page.getByRole('textbox', { name: 'City' }).click();
  await page.getByRole('textbox', { name: 'City' }).press('ControlOrMeta+a');
  await page.getByRole('textbox', { name: 'City' }).fill('');
  await page.getByRole('textbox', { name: 'State' }).click();
  await page.getByRole('textbox', { name: 'State' }).press('ControlOrMeta+a');
  await page.getByRole('textbox', { name: 'State' }).fill('');
  await page.getByRole('textbox', { name: 'Zip Code' }).click();
  await page.getByRole('textbox', { name: 'Zip Code' }).press('ControlOrMeta+a');
  await page.getByRole('textbox', { name: 'Zip Code' }).fill('');
  await saveRecord(page);

  // Check if address fields re-populate
  await expect(page.getByRole('textbox', { name: 'Street 1' })).toHaveValue('1373 Post St');
  await expect(page.getByRole('textbox', { name: 'City' })).toHaveValue('San Francisco');
  await expect(page.getByRole('textbox', { name: 'State' })).toHaveValue('California');
  await expect(page.getByRole('textbox', { name: 'Zip Code' })).toHaveValue('CA 94109');

  // Remove data
  await page.getByRole('menuitem', { name: 'Delete' }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();

  console.log('Contact Extension address fields auto-fill verified successfully.');
});
////////////////////////////////////////////////////////////////////////
*/
////////////////////////////// MATT-13503 //////////////////////////////
// This tests requires the contact "Playwright Test Reserved" to have the proper data on the Address tab
test('Contact - Verticals & Expertises multiple assignment', async ({ page }) => {
  console.log('Checking if Contact form allows multiple Verticals & Expertises assignment...');

  await startTest(page);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Contacts').click();
  await changeView(page, 'Active Contacts');
  await searchRecord(page, 'Playwright Test Reserved', 'Contact Filter by keyword', true);

  // Check Vertical options and assign multiple
  await page.getByRole('region', { name: 'Verticals' }).getByLabel('More commands for Customer').click();
  await page.getByRole('menuitem', { name: 'New Customer Category' }).click();
  await page.getByRole('button', { name: 'Search records for Value,' }).click();

  var dropdown = await page.locator('//div[@aria-label="Dropdown panel"]');
  await expect(dropdown.locator('//span[text()="Construction"]')).toBeVisible();
  await expect(dropdown.locator('//span[text()="Contracting"]')).toBeVisible();
  await expect(dropdown.locator('//span[text()="Habitational"]')).toBeVisible();
  await expect(dropdown.locator('//span[text()="Manufacturing"]')).toBeVisible();
  await expect(dropdown.locator('//span[text()="Real Estate"]')).toBeVisible();

  await dropdown.locator('//span[text()="Construction"]').click();
  await page.getByRole('button', { name: 'Save and Close', exact: true }).click();
  await page.getByRole('region', { name: 'Verticals' }).getByLabel('More commands for Customer').click();
  await page.getByRole('menuitem', { name: 'New Customer Category' }).click();
  await page.getByRole('button', { name: 'Search records for Value,' }).click();
  await dropdown.locator('//span[text()="Contracting"]').click();
  await page.getByRole('button', { name: 'Save and Close', exact: true }).click();

  // Check Expertise options and assign multiple
  await page.getByRole('region', { name: 'Expertise' }).getByLabel('More commands for Customer').click();
  await page.getByRole('menuitem', { name: 'New Customer Category' }).click();
  await page.getByRole('button', { name: 'Search records for Value,' }).click();

  await expect(dropdown.locator('//span[text()="Niche"]')).toBeVisible();
  await expect(dropdown.locator('//span[text()="Vertical"]')).toBeVisible();

  await page.getByText('Niche').click();
  await page.getByRole('button', { name: 'Save and Close', exact: true }).click();
  await page.getByRole('region', { name: 'Expertise' }).getByLabel('More commands for Customer').click();
  await page.getByRole('menuitem', { name: 'New Customer Category' }).click();
  await page.getByRole('button', { name: 'Search records for Value,' }).click();
  await page.locator('//div[@aria-label="Dropdown panel"]').getByText('Vertical').click();
  await page.getByRole('button', { name: 'Save and Close', exact: true }).click();

  // Remove data
  await page.getByRole('region', { name: 'Verticals' }).getByText('').first().click();
  await page.getByRole('region', { name: 'Verticals' }).getByLabel('More commands for Customer').click();
  await page.getByRole('menuitem', { name: 'Delete Customer Category' }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();
  await page.getByRole('region', { name: 'Expertise' }).getByText('').first().click();
  await page.getByRole('region', { name: 'Expertise' }).getByLabel('More commands for Customer').click();
  await page.getByRole('menuitem', { name: 'Delete Customer Category' }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();

  console.log('Contact form allows multiple Verticals & Expertises assignment.');
});
////////////////////////////////////////////////////////////////////////

////////////////////////////// MATT-13269 //////////////////////////////
const emailAsterisk = '//div[@title="Email - Type the primary email address for the contact."]//span[text()="*"]';
const businessPhoneAsterisk = '//div[@title="Business Phone - Type the main phone number for this contact."]//span[text()="*"]'; 
const mobilePhoneAsterisk = '//div[@title="Mobile Phone - Type the mobile phone number for the contact."]//span[text()="*"]';

async function checkAsterisks(page: Page, emailRequired: boolean, businessPhoneRequired: boolean, mobilePhoneRequired: boolean) {
  // Check if the * simbol exists for Bsuiness Phone, Mobile Phone and Email fields. If so, the fields are required.
  if (emailRequired)
    await expect(page.locator(emailAsterisk)).toBeVisible();
  else{
    await expect(page.locator(emailAsterisk)).not.toBeVisible();
  }

  if(businessPhoneRequired){
    await expect(page.locator(businessPhoneAsterisk)).toBeVisible();
  }else{
    await expect(page.locator(businessPhoneAsterisk)).not.toBeVisible();
  }

  if(mobilePhoneRequired){
    await expect(page.locator(mobilePhoneAsterisk)).toBeVisible();
  }else{
    await expect(page.locator(mobilePhoneAsterisk)).not.toBeVisible();
  }
}

test('Contact Quick Form - Phone & Email fields', async ({ page }) => {
  console.log('Checking if phones and email fields are required...');
  
  await startTest(page);
  let tabVisible = await page.locator("//ul[@data-id='quickCreateLauncher']//button[@aria-label='Contact']").isVisible();
  while(!tabVisible){
    await page.locator("//button[@aria-label='Create New Record. New']").click();
    await page.waitForTimeout(2000);
    tabVisible = await page.locator("//ul[@data-id='quickCreateLauncher']//button[@aria-label='Contact']").isVisible();
  }
  await page.locator("//ul[@data-id='quickCreateLauncher']//button[@aria-label='Contact']").click();

  await checkAsterisks(page, true, true, true);

  // Set email
  await page.getByRole('textbox', { name: 'Email' }).click();
  await page.getByRole('textbox', { name: 'Email' }).fill('Test@test.com');
  await page.getByRole('textbox', { name: 'Email' }).press('Enter');
  await checkAsterisks(page, true, false, false);
  
  // Remove email
  await page.getByRole('textbox', { name: 'Email' }).press('ControlOrMeta+a');
  await page.getByRole('textbox', { name: 'Email' }).fill('');
  await page.getByRole('textbox', { name: 'Email' }).press('Enter');
  await checkAsterisks(page, true, true, true);
  
  // Set business phone
  await page.getByRole('textbox', { name: 'Business Phone' }).click();
  await page.getByRole('textbox', { name: 'Business Phone' }).fill('123456');
  await page.getByRole('textbox', { name: 'Business Phone' }).press('Enter');
  await checkAsterisks(page, false, true, false);
  
  // Remove business phone
  await page.getByRole('textbox', { name: 'Business Phone' }).press('ControlOrMeta+a');
  await page.getByRole('textbox', { name: 'Business Phone' }).fill('');
  await page.getByRole('textbox', { name: 'Business Phone' }).press('Enter');
  await checkAsterisks(page, true, true, true);

  // Set mobile phone
  await page.getByRole('textbox', { name: 'Mobile Phone' }).click();
  await page.getByRole('textbox', { name: 'Mobile Phone' }).fill('123456');
  await page.getByRole('textbox', { name: 'Mobile Phone' }).press('Enter');
  await checkAsterisks(page, false, false, true);
  
  // Remove mobile phone
  await page.getByRole('textbox', { name: 'Mobile Phone' }).press('ControlOrMeta+a');
  await page.getByRole('textbox', { name: 'Mobile Phone' }).fill('');
  await page.getByRole('textbox', { name: 'Mobile Phone' }).press('Enter');
  await checkAsterisks(page, true, true, true);
  
  await page.getByRole('button', { name: 'Close', exact: true }).click();

  console.log('Phone and Email fields are required on quick create form.');
});
////////////////////////////////////////////////////////////////////////