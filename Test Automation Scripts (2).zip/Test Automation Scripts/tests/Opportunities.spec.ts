import { test, expect, Page } from '@playwright/test';
import { locatorShortcuts, LoginAccess } from '../Utils/commonVars';
import { openSiteMap, searchRecord, startTest, advancedSearch, saveRecord } from '../Utils/GeneralFunctions.ts';
import { create } from 'domain';

////////////////////////////// MATT-13196 //////////////////////////////
const opTypeName = '//ul[@aria-label="Lookup results"]//span[contains(@data-id, "name")]';

async function checkIfDashboardTabIsHidden(page: Page, opType: string) {
  await page.getByRole('button', { name: 'Search records for Opportunity Type, Lookup field' }).click();
  await page.locator(opTypeName).getByText(opType).click();
  await expect(page.locator('//ul[@role="tablist"]//li[@aria-label="Dashboard"]')).not.toBeVisible();
  await page.getByRole('button', { name: `Delete ${opType}` }).click();
}

test('Opportunity Form - Book Review fields', async ({ page }) => {
  console.log('Testing if "Book Review" exclusive fields hide and show-up correctly...');

  // Select the first Active Account from the list
  await startTest(page, 250000);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Opportunities').click();

  // Create a new Parent Opportunity record
  console.log('Creating a new Parent Opportunity record with "Book Review" type...');
  await page.getByRole('menuitem', { name: 'New', exact: true }).click();
  await expect(page.getByRole('tab', { name: 'Dashboard' })).not.toBeVisible();

  // Check if Dashboard tab is hidden for other Opportunity Types
  await checkIfDashboardTabIsHidden(page, 'Agency Visit');
  await checkIfDashboardTabIsHidden(page, 'Cross Sell');
  await checkIfDashboardTabIsHidden(page, 'Former Opportunity');
  await checkIfDashboardTabIsHidden(page, 'Win-Back');

  // Check if Dashboard tab is visible for Book Review Opportunity Type
  await page.getByRole('button', { name: 'Search records for Opportunity Type, Lookup field' }).click();
  await page.getByText('Book Review').click();
  await page.getByRole('combobox', { name: 'Date of Next Follow Up Date' }).click();
  await page.getByLabel('Date of Next Follow Up Date').click();
  await page.getByRole('combobox', { name: 'Date of Next Follow Up Date' }).fill('12/12/2025');
  await page.getByRole('combobox', { name: 'Date of Next Follow Up Date' }).press('Enter');
  await expect(page.locator('//ul[@role="tablist"]//li[@aria-label="Dashboard"]')).toBeVisible();

  // Fill the required fields and save the Parent Opportunity record
  await page.locator('//input[@aria-label="Topic"]').click();
  await page.locator('//input[@aria-label="Topic"]').fill('Playwright Book Review Test - Parent');
  await page.getByRole('button', { name: 'Search records for Contact,' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Reserved', 'Choose contact for Contact');
  await page.getByRole('button', { name: 'Search records for Agency' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Reserved', 'Choose account for Agency');

  await saveRecord(page);
  console.log('Parent Opportunity record created.');

  // Check if Book Review exclusive fields are visible
  await page.locator('//ul[@role="tablist"]//li[@aria-label="Dashboard"]').click();
  await expect(page.getByText('Number of Open Opportunities')).toBeVisible();
  await expect(page.getByText('Number of Won Opportunities')).toBeVisible();
  await expect(page.getByText('Number of Lost Opportunities')).toBeVisible();
  await expect(page.getByText('Total $ of Open Opportunities')).toBeVisible();
  await expect(page.getByText('Total $ of Won Opportunities')).toBeVisible();
  await expect(page.getByText('Total $ of Lost Opportunities')).toBeVisible();

  await page.getByRole('button', { name: 'Save More Commands. Save (' }).click();
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();
  await page.waitForTimeout(2000);

  // Create a new Child Opportunity record
  console.log('Creating a new Child Opportunity record with "Book Review" type...');
  await page.getByRole('menuitem', { name: 'New', exact: true }).click();
  await page.getByRole('button', { name: 'Search records for Opportunity Type, Lookup field' }).click();
  await page.getByText('Book Review').click();
  await page.getByRole('textbox', { name: 'Topic' }).click();
  await page.getByRole('textbox', { name: 'Topic' }).fill('Playwright Book Review Test - Child');
  await page.getByRole('button', { name: 'Search records for Contact,' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Reserved', 'Choose contact for Contact');
  await page.getByRole('button', { name: 'Search records for Agency' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Reserved', 'Choose account for Agency');

  // Set Parent Opportunity lookup to the previously created Parent Opportunity
  await page.locator('//div[@title="Created"]/div').click();
  await page.locator('//button[@aria-label="Search records for Parent Opportunity, Lookup field" and @title="Search"]').click();
  await page.locator('//span[text()="Advanced"]').click();
  await advancedSearch(page, 'Playwright Book Review Test - Parent', 'Choose opportunity for Parent Opportunity');

  await page.getByRole('button', { name: 'Search records for Producer' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test For Opportunity', 'Choose producer code for');
  await page.getByRole('textbox', { name: 'Insured Name' }).click();
  await page.getByRole('textbox', { name: 'Insured Name' }).fill('Playwright Test Reserved');
  await page.getByRole('combobox', { name: 'Date of Effective Date' }).click();
  await page.getByLabel('Date of Effective Date').click();
  await page.getByRole('combobox', { name: 'Date of Effective Date' }).fill('6/25/2027');
  await page.getByRole('combobox', { name: 'Date of Effective Date' }).press('Enter');
  await page.getByRole('combobox', { name: 'Date of Next Follow Up Date' }).click();
  await page.getByLabel('Date of Next Follow Up Date').click();
  await page.getByRole('combobox', { name: 'Date of Next Follow Up Date' }).fill('12/12/2025');
  await page.getByRole('combobox', { name: 'Date of Next Follow Up Date' }).press('Enter');

  await saveRecord(page);
  console.log('Child Opportunity record created.');

  // Check if Book Review exclusive fields are visible
  await page.getByRole('tab', { name: 'Policy Details' }).click();

  await expect(page.getByText('Expiration Date')).toBeVisible();
  await expect(page.getByText('SIC Description')).toBeVisible();
  await expect(page.getByText('NAICS Code #')).toBeVisible();
  await expect(page.getByText('NAICS Code Description')).toBeVisible();
  await expect(page.getByText('Customer Service Rep')).toBeVisible();
  await expect(page.getByText('Account Manager', { exact: true })).toBeVisible();
  await expect(page.getByText('Producer', { exact: true })).toBeVisible();
  await expect(page.getByText('VIP')).toBeVisible();
  await expect(page.getByText('Office')).toBeVisible();
  await expect(page.getByText('Commission %')).toBeVisible();
  await expect(page.getByText('Commission $')).toBeVisible();
  await expect(page.locator('//section[@aria-label="New Section"]').getByText('Line of Business')).toBeVisible();
  await expect(page.getByText('Billing Company')).toBeVisible();
  await expect(page.getByText('Class', { exact: true })).toBeVisible();

  console.log('All "Book Review" exclusive fields are visible as expected.');

  // Removing test data
  await page.getByRole('link', { name: 'Playwright Book Review Test' }).click();
  await page.getByRole('menuitem', { name: 'Delete (CTRL+D)' }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();
  await page.waitForTimeout(8000);
  await page.getByRole('menuitem', { name: 'Delete (CTRL+D)' }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();

  console.log('Test completed successfully.');
});
////////////////////////////////////////////////////////////////////////