import { test, expect } from '@playwright/test';
import { LoginAccess, locatorShortcuts } from '../Utils/commonVars.ts';
import { openSiteMap, advancedSearch, saveRecord, searchRecord, changeView, startTest } from '../Utils/GeneralFunctions.ts';
import { createAccount } from './Account.spec.ts';

////////////////////////////// MATT-12987 //////////////////////////////
test('Task - Reopen Closed records', async ({ page }) => {
  console.log('Testing ReOpenning function in Tasks...');

  await startTest(page);
  
  // Create Task record
  console.log('Creating Task record...');
  
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Activities').click();
  
  await page.getByRole('menuitem', { name: 'Task' }).click();
  await page.getByRole('textbox', { name: 'Subject' }).click();
  await page.getByRole('textbox', { name: 'Subject' }).fill('Playwright Test');
  await page.locator('//button[@aria-label="Search records for Regarding, Lookup field"]').click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Reserved', 'Choose record for Regarding');
  await saveRecord(page);
  console.log('Task record created successfully.');

  // Complete task
  await page.getByRole('menuitem', { name: 'Mark Complete' }).click();
  await changeView(page, 'All Completed Tasks Last 30 Days');
  await searchRecord(page, 'Playwright Test', 'Task Filter by keyword', true);
  await expect(page.getByText('Read-only This record’s status: Completed', { exact: true })).not.toHaveCount(0);

  // Re-open and edit Task record
  console.log('Re-opening and editing Task record...');
  await page.getByRole('menuitem', { name: 'ReOpen' }).click();
  await page.getByRole('textbox', { name: 'Description' }).click();
  await page.getByRole('textbox', { name: 'Description' }).fill('Playwright Test');
  await page.locator('//input[@aria-label="Duration"]').click();
  await page.getByRole('option', { name: '15 minutes' }).click();
  await saveRecord(page);
  console.log('Task record reopened and edited successfully.');

  // Close, re-open and edit Task record
  await page.getByRole('menuitem', { name: 'Close Task' }).click();
  await page.getByRole('combobox', { name: 'State' }).click();
  await page.getByRole('option', { name: 'Canceled' }).click();
  await page.waitForTimeout(1000);
  await page.getByRole('button', { name: 'Close Task' }).click();
  await expect(page.getByText('Read-only This record’s status: Canceled', { exact: true })).not.toHaveCount(0);

  console.log('Re-opening and editing Task record...');
  await page.getByRole('menuitem', { name: 'ReOpen' }).click();
  await page.getByRole('textbox', { name: 'Subject' }).click();
  await page.getByRole('textbox', { name: 'Subject' }).fill('Playwright Test Closed');
  await page.getByRole('textbox', { name: 'Description' }).click();
  await page.getByRole('textbox', { name: 'Description' }).fill('Playwright Test Closed');
  await page.getByRole('button', { name: 'Delete Playwright Test' }).click();
  await page.getByRole('button', { name: 'Open Duration' }).click();
  await page.getByRole('option', { name: '1.5 hours' }).click();
  await saveRecord(page);
  console.log('Task record reopened and edited successfully.');

  // Delete Task record
  await page.getByRole('menuitem', { name: 'Delete' }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();
});
////////////////////////////////////////////////////////////////////////