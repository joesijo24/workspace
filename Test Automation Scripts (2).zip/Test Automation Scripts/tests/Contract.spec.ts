import { test, expect } from '@playwright/test';
import { locatorShortcuts, LoginAccess } from '../Utils/commonVars.ts';
import { advancedSearch, openSiteMap, startTest, saveRecord, changeView, searchRecord } from '../Utils/GeneralFunctions.ts';
import { createAccount } from './Account.spec.ts';

////////////////////////////// MATT-12971 //////////////////////////////
test('Contracts - CRUD Operations', async ({ page }) => {
  console.log('Testing multiple territories assignment...');
  
  await startTest(page);
  await openSiteMap(page);
  await page.getByRole('button', { name: 'Sales (change area)' }).click();
  await page.getByText('App Settings').click();
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Contracts').click();

  await page.getByRole('menuitem', { name: 'New', exact: true }).click();
  await page.getByRole('textbox', { name: 'Name' }).click();
  await page.getByRole('textbox', { name: 'Name' }).fill('Playwright Multiple Territory Test');
  await page.getByRole('button', { name: 'Search records for Account,' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Reserved', 'Choose account for Account');
  await page.getByRole('button', { name: 'Search records for OU' }).click();
  await page.getByText('Acadia Insurance Company').click();
  await page.getByRole('button', { name: 'Search records for Business' }).click();
  await page.getByText('Guidewire').click();
  await page.locator('//input[@aria-label="Date of Effective Date"]').fill('10/10/2027');
  await page.locator('//input[@aria-label="Date of Expiration Date"]').fill('11/10/2027');
  await page.getByRole('textbox', { name: 'Annual Premium Goal' }).click();
  await page.getByRole('textbox', { name: 'Annual Premium Goal' }).fill('10000');
  await page.getByRole('textbox', { name: 'Annual New Business Premium' }).click();
  await page.getByRole('textbox', { name: 'Annual New Business Premium' }).fill('100000');
  await page.getByRole('button', { name: 'Search records for Signed by' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Reserved', 'Choose contact for Signed by');
  await page.waitForTimeout(2000);

  // Check if contact details are correct
  await expect(page.locator('//input[@aria-label ="Email" and @title="playwright@test.com"]')).toBeVisible();
  await expect(page.locator('//input[@aria-label ="Business Phone" and @title="123456789"]')).toBeVisible();
  await expect(page.locator('//input[@aria-label ="Mobile Phone" and @title="12345678"]')).toBeVisible();

  await page.getByRole('button', { name: 'Search records for Payment' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test 2 Reserved', 'Choose contact for Payment');
  await page.waitForTimeout(2000);

  // Check if contact details are correct
  await expect(page.locator('//input[@aria-label ="Email" and @title="playwright2@test.com"]')).toBeVisible();
  await expect(page.locator('//input[@aria-label ="Business Phone" and @title="123456"]')).toBeVisible();
  await expect(page.locator('//input[@aria-label ="Mobile Phone" and @title="12345"]')).toBeVisible();

  await page.getByRole('button', { name: 'Search records for Producer' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Reserved', 'Choose producer code for');
  await saveRecord(page)

  // Deactivate the contract
  await page.getByRole('menuitem', { name: 'Deactivate' }).click();
  await page.getByRole('button', { name: 'Deactivate' }).click();
  await page.waitForTimeout(2000);
  await expect(page.getByText('Read-only This record’s status: Inactive', { exact: true })).toBeVisible();

  // Search for contract on inactive view and reactivate it
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Contracts').click();
  await changeView(page, 'Inactive Contracts');
  await searchRecord(page, 'Playwright Multiple Territory Test',  'Contract Filter by keyword', true);
  await page.getByRole('menuitem', { name: 'Activate' }).click();
  await page.getByRole('button', { name: 'Activate' }).click();
  await page.waitForTimeout(2000);
  await expect(page.getByText('Read-only This record’s status: Inactive', { exact: true })).not.toBeVisible();

  // Search for contract on active view and delete it
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Contracts').click();
  await searchRecord(page, 'Playwright Multiple Territory Test',  'Contract Filter by keyword', false);
  await page.getByLabel('Press SPACE to select this').getByText('').click();
  await page.getByRole('button', { name: 'Delete', exact: true }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();

  console.log('Contracts - CRUD Operations test completed successfully.');  
});
////////////////////////////////////////////////////////////////////////