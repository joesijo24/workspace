import { test, expect } from '@playwright/test';
import { LoginAccess } from '../Utils/commonVars.ts';
import { advancedSearch, openSiteMap, startTest, saveRecord, searchRecord } from '../Utils/GeneralFunctions.ts';
import { createAccount } from './Account.spec.ts';

////////////////////////////// MATT-12997 //////////////////////////////
// Remember to clean the OU-Appetite record created after the test
test('OU Appetite - CRUD Operations from Business Unit', async ({ page }) => {
  console.log('Testing CRUD Operations for OU Appetite from Business Unit...');
  await startTest(page);
  
  // Go to Business Unit record "Berkley Aspire"
  await openSiteMap(page);
  await page.getByRole('button', { name: 'Sales (change area)' }).click();
  await page.getByText('App Settings').click();
  await page.getByText('Business Units').click();
  await searchRecord(page, 'Berkley Aspire', 'Business Unit Filter by', true);

  // Create new OU Appetite record
  await page.getByRole('menuitem', { name: 'New OU Appetite. Add New OU' }).click();
  await page.getByLabel('dismiss').click();
  await page.getByRole('button', { name: 'Search records for Line of' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Environmental', 'Choose category for Line of');
  await page.waitForTimeout(2000);
  await page.getByRole('combobox', { name: 'Classes to Include' }).click();
  await page.getByRole('option', { name: 'Include Only These' }).click();
  await page.waitForTimeout(2000);
  await page.getByRole('combobox', { name: 'States to Include' }).click();
  await page.getByRole('option', { name: 'Include All Except These' }).click();
  await saveRecord(page);
  await page.getByRole('menuitem', { name: 'New OU Appetite Class. Add' }).click();
  await page.getByRole('button', { name: 'Search records for Class,' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, '111411 - Mushroom Production', 'Choose record for Class');
  await page.getByRole('button', { name: 'Save and Close', exact: true }).click();
  await page.getByRole('menuitem', { name: 'New OU Appetite State. Add' }).click();
  await page.getByRole('button', { name: 'Search records for State,' }).click();
  await page.getByText('Alabama').click();

  // Set Zip Codes to Exclude
  await page.waitForTimeout(2000);
  await page.getByRole('combobox', { name: 'Zip Codes to Include' }).click();
  await page.getByRole('option', { name: 'Include All Except These' }).click();
  await page.getByRole('textbox', { name: 'Zip Codes' }).click();
  await page.getByRole('textbox', { name: 'Zip Codes' }).fill('35004, 35005, 35006');

  // Test if "Include All" hides and cleans "Zip Codes" section
  await page.getByRole('combobox', { name: 'Zip Codes to Include' }).click();
  await page.getByRole('option', { name: 'Include All', exact: true }).click();
  await expect(page.locator('//div[@data-control-name="wrb_zipcodes"]')).toHaveCount(0);
  await page.getByRole('combobox', { name: 'Zip Codes to Include' }).click();
  await page.getByRole('option', { name: 'Include All Except These' }).click();
  await expect(page.locator('//div[@data-control-name="wrb_zipcodes"]')).toHaveCount(1);
  await expect(page.locator('//textarea[@aria-label="Zip Codes"]')).toHaveText('');

  // Re-set zip values
  await page.getByRole('textbox', { name: 'Zip Codes' }).click();
  await page.getByRole('textbox', { name: 'Zip Codes' }).fill('35004, 35005, 35006');
  await page.getByRole('button', { name: 'Save and Close', exact: true }).click();

  await page.getByRole('menuitem', { name: 'Save & Close' }).click();

  console.log('OU Appetite - CRUD Operations from Business Unit passed. Remember to delete the created OU Appetite record after testing.');
});
////////////////////////////////////////////////////////////////////////
