import { test, expect } from '@playwright/test';
import { locatorShortcuts, LoginAccess } from '../Utils/commonVars';
import { advancedSearch, openSiteMap, saveRecord, searchRecord, startTest } from '../Utils/GeneralFunctions.ts';

////////////////////////////// MATT-12497 //////////////////////////////
test('Segmentation Form - CRUD operations', async ({ page }) => {
  console.log('Testing Segmentation CRUD operations...');
  
  await startTest(page);
  await openSiteMap(page);

  // Navigate to Segmentation
  await page.getByRole('button', { name: 'Sales (change area)' }).click();
  await page.getByText('App Settings').click();
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Categories').click();

  // Create Father Category
  await page.getByRole('menuitem', { name: 'New', exact: true }).click();
  await page.getByRole('textbox', { name: 'Title' }).click();
  await page.getByRole('textbox', { name: 'Title' }).fill('Playwright Test Father');
  await page.getByRole('textbox', { name: 'Description' }).click();
  await page.getByRole('textbox', { name: 'Description' }).fill('Parent Test');
  await page.waitForTimeout(3000);
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();
  await page.waitForTimeout(3000);

  // Create Children Category
  await page.getByRole('menuitem', { name: 'New', exact: true }).click();
  await page.getByRole('textbox', { name: 'Title' }).click();
  await page.getByRole('textbox', { name: 'Title' }).fill('Playwright Test Children');
  await page.getByRole('button', { name: 'Search records for Parent' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Father', 'Choose category for Parent');
  await page.getByRole('textbox', { name: 'Description' }).click();
  await page.getByRole('textbox', { name: 'Description' }).fill('Children Test');
  await page.waitForTimeout(3000);
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();
  await page.waitForTimeout(3000);

  // Search for the categories, modify and delete them
  await searchRecord(page, 'Playwright Test', 'Category Filter by keyword', false);

  await expect(page.locator('//div[@col-id="title"]//span[text()="Playwright Test Father"]')).toBeVisible();
  await expect(page.getByRole('link', { name: 'Playwright Test Children' })).toBeVisible();

  await page.getByRole('link', { name: 'Playwright Test Children' }).click();
  await page.getByRole('textbox', { name: 'Description' }).click();
  await page.getByRole('textbox', { name: 'Description' }).fill('Children Test Modification');
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();

  console.log('Segmentation CRUD operations tested successfully.');
});

test('Segmentation Form - OU-Specific Account CRUD operations', async ({ page }) => {
  console.log('Testing OU-Specific Account CRUD operations...');
  
  await startTest(page);
  await openSiteMap(page);

  // Create New Account
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Accounts').click();
  await page.getByRole('menuitem', { name: 'New', exact: true }).click();
  await page.getByRole('textbox', { name: 'Account Name' }).click();
  await page.getByRole('textbox', { name: 'Account Name' }).fill('Playwright Segmentation Account');
  await page.getByRole('button', { name: 'Search records for Account' }).click();
  await page.getByText('Agency', { exact: true }).click();
  await page.getByRole('button', { name: 'Search records for State,' }).scrollIntoViewIfNeeded();
  await page.getByRole('combobox', { name: 'State, Lookup' }).click();
  await page.getByRole('combobox', { name: 'State, Lookup' }).fill('Alabama');
  await page.locator('//div[@aria-label="State Lookup results"]//span[text()="Alabama"]').click();
  await saveRecord(page)

  // Add Segmentation
  await page.getByRole('tab', { name: 'OU-Specific' }).click();
  await page.getByRole('button', { name: 'Search records for Segmentation, Lookup field' }).click();
  await page.getByRole('button', { name: 'New', exact: true }).click();
  await page.getByRole('textbox', { name: 'Title' }).click();
  await page.getByRole('textbox', { name: 'Title' }).fill('Playwright Test Category');
  await page.getByRole('textbox', { name: 'Description' }).click();
  await page.getByRole('textbox', { name: 'Description' }).fill('Test Description');
  await page.getByRole('button', { name: 'Save and Close', exact: true }).click();
  await page.waitForTimeout(3000);
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();
  
  console.log('OU-Specific Account CRUD operations tested successfully.');
});

// This test assumes that the data created in the previous test is still present and that the roles have been changed to a user
test('Segmentation Form - User restrictions for Segmentation', async ({ page }) => {
  console.log('Testing Segmentation CRUD operations...');

  await startTest(page);
  await openSiteMap(page);

  // Checks account's extension
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Accounts').click();
  await searchRecord(page, 'Playwright Segmentation Account', 'Account Filter by keyword', true);
  await page.getByRole('tab', { name: 'OU-Specific' }).click();
  await expect(page.getByRole('button', { name: 'Search records for Segmentation, Lookup field' })).not.toBeVisible();
  await page.locator("//div[@title='Account Extension - A lookup to the related Account Extension record. ']/..//ul//div/div").click();
  await expect(page.getByRole('button', { name: 'Search records for Segmentation, Lookup field' })).not.toBeVisible();

  console.log('Segmentation CRUD operations restrictions for User role tested successfully.');
});

test('Segmentation Form - Clean test data', async ({ page }) => {
  console.log('Testing Segmentation CRUD operations...');
  
  await startTest(page);
  await openSiteMap(page);

  // Delete Account and its related data
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Accounts', { exact: true }).click();
  await searchRecord(page, 'Playwright Segmentation Account', 'Account Filter by keyword', true);
  await page.getByRole('tab', { name: 'OU-Specific' }).click();
  await page.locator("//div[@title='Account Extension - A lookup to the related Account Extension record. ']/..//ul//div/div").click();
  await page.getByRole('link', { name: 'Playwright Test Category' }).click();
  await page.getByRole('menuitem', { name: 'Delete' }).click();
  await page.getByRole('button', { name: 'Yes' }).click();
  await page.getByRole('menuitem', { name: 'Delete' }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();
  await page.getByRole('menuitem', { name: 'More commands for Account', exact: true }).click();
  await page.locator('//button[@aria-label="Delete" and @role="menuitem"]').click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();

  // Delete Category
  await page.getByRole('button', { name: 'Sales (change area)' }).click();
  await page.getByText('App Settings').click();
  await page.getByText('Categories').click();
  await searchRecord(page, 'Playwright Test', 'Category Filter by keyword', false);
  await page.locator('//div[@class="ag-header-container"]//i[@data-icon-name="CheckMark"]').click();
  await page.getByRole('button', { name: 'Delete', exact: true }).click();
  await page.getByRole('button', { name: 'Yes' }).click();
});
////////////////////////////////////////////////////////////////////////