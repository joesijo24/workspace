import { test, expect, Page } from '@playwright/test';
import { locatorShortcuts, LoginAccess } from '../Utils/commonVars.ts';
import { changeView, openSiteMap, saveRecord, searchRecord, startTest } from '../Utils/GeneralFunctions.ts';

////////////////////////////// MATT-14571 //////////////////////////////
var mapWindow: any;
async function addLocation(page: Page, direction: string){
  await mapWindow.getByRole('searchbox', { name: 'Search Record or Location' }).click();
  await mapWindow.getByRole('searchbox', { name: 'Search Record or Location' }).fill(direction);
  await mapWindow.locator('//ul[@class="ui-autocomplete ui-front ui-menu ui-widget ui-widget-content"]/li').nth(2).click();
  await page.waitForTimeout(4000);
  await mapWindow.locator('canvas').nth(1).click({
    position: {
      x: 708,
      y: 515
    }, button: 'right'
  });
  await mapWindow.getByRole('menuitem', { name: 'Add to Route' }).click();
  await page.waitForTimeout(2000);
}

test('Maplytics Route - Creating a trip through maplytics', async ({ page }) => {
  console.log('Testing if the creation of a route (Trip) automatically links it with Agency Visits and Meetings...');
  
  await startTest(page, 160000);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Maplytics', { exact: true }).click();

  // Create a route with 2 stops
  mapWindow = await page.locator('iframe[name="ikl_/Maplytics/Maplytics.DetailMap.html"]').contentFrame();
  await mapWindow.locator('#selectEntity_0').selectOption('wrb_producercode');
  await mapWindow.locator('#viewselectEntity_0').selectOption('85a8c473-74b5-42c9-8777-558960a77938');
  await mapWindow.getByRole('button', { name: 'Search' }).click();

  await addLocation(page, '17 S Main St Deer Park WA 99006 United States');
  await addLocation(page, '601 E Front Ave Coeur d\'Alene ID 83814 United States');

  // Set and save route details
  await mapWindow.getByRole('button', { name: 'Go' }).click();
  await mapWindow.locator('.icon-sprite.route-icon').click();
  await mapWindow.getByRole('textbox', { name: 'Enter the route name' }).click();
  await mapWindow.getByRole('textbox', { name: 'Enter the route name' }).fill('Playwright Route Test');
  await mapWindow.locator('#routedatepicker').click();
  await mapWindow.locator('#routedatepicker').fill('12/12/2027');
  await mapWindow.getByRole('button', { name: 'Save' }).click();
  
  await page.waitForTimeout(20000);
});

async function checkMeeting(page: Page, row: number){
  // Verify linked Agency Visits and Meetings
  await page.locator('//div[@data-id="dataSetRoot_Subgrid_new_2"]').filter({ hasText: 'Agency Visits' }).locator('//div[@role="row" and @row-index="' + row + '"]//div[@col-id="wrb_name"]//a[@role="link"]').click();
  await expect(page.locator('//ul[@title="Outlook Invite (Meeting)"]//div[@role="link"]')).toHaveCount(1);
  await page.locator('//button[@title="Go back"]').click();
}

test('Maplytics Route - Checking if meetings were created', async ({ page }) => {
  await startTest(page);
  await openSiteMap(page);

  // Search for route on "Trips" view and open it
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Trips', { exact: true }).click();
  await searchRecord(page, 'Playwright Route Test', 'Apply begins with filter on', false);

  checkMeeting(page, 0);
  checkMeeting(page, 1);

  // Removes record
  await page.getByRole('menuitem', { name: 'Delete' }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();
});

////////////////////////////////////////////////////////////////////////