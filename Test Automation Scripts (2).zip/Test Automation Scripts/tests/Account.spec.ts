import { test, expect, Page } from '@playwright/test';
import { locatorShortcuts } from '../Utils/commonVars';
import { openSiteMap, searchRecord, startTest, advancedSearch, saveRecord } from '../Utils/GeneralFunctions.ts';

export async function createAccount(page: Page, save: boolean, name: string, accountType: string, state: string) {
  await page.getByRole('menuitem', { name: 'New', exact: true }).click();
  await page.getByRole('textbox', { name: 'Account Name' }).click();
  await page.getByRole('textbox', { name: 'Account Name' }).fill(name);
  await page.getByRole('button', { name: 'Search records for Account' }).click();
  await page.getByText(accountType, { exact: true }).click();
  await page.getByRole('button', { name: 'Search records for State,' }).scrollIntoViewIfNeeded();
  await page.getByRole('combobox', { name: 'State, Lookup' }).click();
  await page.getByRole('combobox', { name: 'State, Lookup' }).fill(state);
  await page.locator('//div[@aria-label="State Lookup results"]//span[text()="'+state+'"]').click();
  await page.getByRole('button', { name: 'Search records for Parent' }).scrollIntoViewIfNeeded();
  await page.getByRole('button', { name: 'Search records for Parent' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Reserved', 'Choose account for Parent');
  if(save){
    await page.getByRole('menuitem', { name: 'Save & Close' }).click();
  }
};

////////////////////////////// MATT-11807 //////////////////////////////
test('Account Form - Account Types field', async ({ page }) => {
  console.log('Testing Account Types field...');

  // Select the first Active Account from the list
  await startTest(page);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Accounts').click();
  await page.getByRole('menuitem', { name: 'New', exact: true }).click();

  // Test "Account Type" field
  await page.getByRole('button', { name: 'Search records for Account' }).click();
  await expect(page.locator('//div[@aria-label="Dropdown panel"]//span[text()="Agency"]')).toBeVisible();
  await expect(page.locator('//div[@aria-label="Dropdown panel"]//span[text()="Office"]')).toBeVisible();

  // Successful Log
  console.log('Account Types field updated successfully.');
});
////////////////////////////////////////////////////////////////////////

////////////////////////////// MATT-11808 //////////////////////////////
test('Account Form - State field', async ({ page }) => {
  console.log('Testing State field...');
  
  await startTest(page);
  let tabVisible = await page.locator("//ul[@data-id='quickCreateLauncher']//button[@aria-label='Account']").isVisible();
  while(!tabVisible){
    await page.locator("//button[@aria-label='Create New Record. New']").click();
    await page.waitForTimeout(2000);
    tabVisible = await page.locator("//ul[@data-id='quickCreateLauncher']//button[@aria-label='Account']").isVisible();
  }
  await page.locator("//ul[@data-id='quickCreateLauncher']//button[@aria-label='Account']").click();

  // Check if the * simbol exists for the State field. If so, the field is required.
  await page.locator('//div[@data-control-name="wrb_state"]').waitFor({ state: 'visible'});
  await expect(page.locator('//div[@data-control-name="wrb_state"]//span[text()="*"]')).toBeVisible();

  console.log('State field is required on quick create form.');

  // Go to main form and check again
  await page.locator("//section[@data-id='quickCreateRoot']//button[@aria-label='Close']").click();
  await page.locator("//div[@aria-label='Navigate Dynamics 365']//li[@aria-label='Accounts']").click();
  await page.locator("//div[@aria-label='Active Accounts']//div[@row-index='0']//div[@col-id='name']//a[@role='link']").click();

  await page.locator('//div[@title="State"]/label[text()="State"]').waitFor({ state: 'visible'});
  await expect(page.locator('//div[@data-control-name="wrb_state"]//span[text()="*"]')).toBeVisible();

  console.log('State field is required on main create form.');
});
////////////////////////////////////////////////////////////////////////

////////////////////////////// MATT-11929 //////////////////////////////
test('Account Hierarchy - Assign child-father account relations', async ({ page }) => {
  console.log('Testing Account Hierarchy relations...');
  
  await startTest(page);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Accounts').click();

  // Create parent account
  await createAccount(page, true, 'Hierarchy Test Father Playwright', 'Agency', 'Alaska');

  // Create child account and assign parent
  await createAccount(page, false, 'Hierarchy Test Child Playwright', 'Office', 'Alaska');
  await page.getByRole('button', { name: 'Search records for Parent' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Hierarchy Test Father Playwright', 'Choose account for Parent');
  await page.waitForTimeout(3000);
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();

  console.log('Account Hierarchy relations assigned successfully.');
});

test('Account Hierarchy - Clean data', async ({ page }) => {
  console.log('Cleaning Account Hierarchy relations...');
  
  await startTest(page);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Accounts').click();
  await searchRecord(page, 'Hierarchy Test', 'Account Filter by keyword', false);
  await page.getByText('').nth(1).click();
  await page.getByLabel('Press SPACE to select this').getByText('').click();
  await page.getByRole('button', { name: 'Delete', exact: true }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();

  console.log('Account Hierarchy relations cleaned successfully.');
});
////////////////////////////////////////////////////////////////////////

////////////////////////////// MATT-12982 //////////////////////////////
// The test will use the reserved account record with a value of "000054321" for NPN
test('Account - Search record by NPN', async ({ page }) => {
  console.log('Testing Searchbox...');
  
  await startTest(page);
  await page.getByRole('searchbox', { name: 'Search' }).click();
  await page.getByRole('searchbox', { name: 'Search' }).fill('000054321');
  await expect(page.locator('//div[text()="Accounts"]/..//label[text()="Playwright Test Reserved"]')).toBeVisible();
  
  console.log('Account record searched successfully by NPN.');
});
////////////////////////////////////////////////////////////////////////

////////////////////////////// MATT-13190 //////////////////////////////
test('Account - Contact role assignment', async ({ page }) => {
  console.log('Testing contact role assignment on Account form...');
  
  await startTest(page);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Accounts').click();
  await searchRecord(page, 'Playwright Test Reserved', 'Account Filter by keyword', true);
  await page.getByRole('tab', { name: 'Contacts' }).click();

  // Adding a new Contact Role
  await page.getByRole('menuitem', { name: 'New Contact Role. Add New' }).click();
  await page.getByRole('button', { name: 'Search records for Contact,' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Reserved', 'Choose contact for Contact');
  await page.getByRole('button', { name: 'Search records for Role,' }).click();
  await page.getByRole('combobox', { name: 'Role, Lookup' }).click();
  await page.getByRole('combobox', { name: 'Role, Lookup' }).fill('Carrier Relations');
  await page.getByText('Carrier Relations', { exact: true }).click();
  await page.getByRole('button', { name: 'Save and Close', exact: true }).click();
  await saveRecord(page);

  // Now delete the created Contact Role
  await page.getByRole('tab', { name: 'Contacts' }).click();
  await page.locator('//section[@aria-label="Contact Roles"]').getByLabel('Press SPACE to select this').getByText('').click();
  await page.getByRole('menuitem', { name: 'More commands for Contact Role' }).click();
  await page.getByRole('menuitem', { name: 'Delete Contact Role' }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();
  await saveRecord(page);
  console.log('Contact role assigned and deleted successfully.');
});
////////////////////////////////////////////////////////////////////////

////////////////////////////// MATT-13270 //////////////////////////////
test('Account - Account Extension view fields', async ({ page }) => {
  console.log('Checking for automatic fill of view fields of Account Extension...');
  
  await startTest(page);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Accounts').click();
  await createAccount(page, false, 'Account Extension View Test', 'Agency', 'California');
  await saveRecord(page);
  console.log('Account created successfully.');
  await page.getByRole('tab', { name: 'OU-Specific' }).click();

  // Update data from Account Extension
  await page.locator('//ul[@title="Account Extension"]/li/div[@role="link"]/div').click();
  await page.getByRole('combobox', { name: 'Segmentation, Lookup' }).click();
  await page.getByRole('combobox', { name: 'Segmentation, Lookup' }).fill('6 - Planting seeds');
  await page.getByText('6 - Planting seeds').click();
  await page.getByRole('textbox', { name: 'Available Premium' }).click();
  await page.getByRole('textbox', { name: 'Available Premium' }).fill('123456');
  await page.getByRole('textbox', { name: 'Available Premium' }).press('Enter');
  await page.waitForTimeout(2000);
  await page.getByRole('combobox', { name: 'Parking On Site?' }).click();
  await page.getByRole('option', { name: 'Yes' }).click();
  await page.getByRole('textbox', { name: 'Pain Points' }).click();
  await page.getByRole('textbox', { name: 'Pain Points' }).fill('Pain Points test');
  await page.getByRole('textbox', { name: 'Growth Goals' }).click();
  await page.getByRole('textbox', { name: 'Growth Goals' }).fill('Growth Goals test');
  await page.getByRole('textbox', { name: 'Competitive Intel' }).click();
  await page.getByRole('textbox', { name: 'Competitive Intel' }).fill('Competitive Intel Test');
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();
  await page.waitForTimeout(2000);
  console.log('Account Extension fields updated successfully.');

  // Check if data is reflected on Account form view fields
  await expect(page.getByRole('list', { name: 'Segmentation' })).toContainText('6 - Planting seeds');
  await expect(page.getByRole('textbox', { name: 'Available Premium' })).toHaveValue('$123,456.00');
  await expect(page.getByRole('combobox', { name: 'Parking On Site?' })).toHaveText('Yes');
  await expect(page.getByRole('textbox', { name: 'Pain Points' })).toHaveValue('Pain Points test');
  await expect(page.getByRole('textbox', { name: 'Growth Goals' })).toHaveValue('Growth Goals test');
  await expect(page.getByRole('textbox', { name: 'Competitive Intel' })).toHaveValue('Competitive Intel Test');
  console.log('Account Extension view fields verified successfully.');

  // Clean up - Delete created Account
  await page.getByRole('menuitem', { name: 'Delete' }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();
});
////////////////////////////////////////////////////////////////////////