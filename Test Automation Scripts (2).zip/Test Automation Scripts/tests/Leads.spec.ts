import { test, expect, Page } from '@playwright/test';
import { LoginAccess, locatorShortcuts } from '../Utils/commonVars.ts';
import { openSiteMap, advancedSearch, saveRecord, searchRecord, changeView, startTest } from '../Utils/GeneralFunctions.ts';
import { createAccount } from './Account.spec.ts';

async function uploadAndScanCard(page: Page, fileName: string, firstName: string, lastName: string, jobTitle: string, companyName: string, email: string, businessPhone: string, mobilePhone: string, city: string, state: string) {
  // Upload Business Card
  await page.locator('//div[@data-id="businesscard-FieldSectionItemContainer"]//input[@type="file"]').setInputFiles(`./Attachments/Business Cards/${fileName}`);

  // Wait for upload to complete
  await page.waitForTimeout(2000);
  await page.locator('//div[@data-id="businesscard-FieldSectionItemContainer"]//div[contains(@class,"Spinner-circle")]').waitFor({ state: 'detached' });

  // Check that fields are populated correctly
  await expect(page.getByRole('textbox', { name: 'First Name' })).toHaveValue(firstName);
  await expect(page.getByRole('textbox', { name: 'Last Name' })).toHaveValue(lastName);
  await expect(page.getByRole('textbox', { name: 'Job Title' })).toHaveValue(jobTitle);
  await expect(page.getByRole('textbox', { name: 'Company Name' })).toHaveValue(companyName);
  await expect(page.getByRole('textbox', { name: 'Email' })).toHaveValue(email);
  await expect(page.getByRole('textbox', { name: 'Business Phone' })).toHaveValue(businessPhone);
  await expect(page.getByRole('textbox', { name: 'Mobile Phone' })).toHaveValue(mobilePhone);
  await expect(page.getByRole('textbox', { name: 'City' })).toHaveValue(city);
}

////////////////////////////// MATT-12980 //////////////////////////////
test('Leads - Business Card Scanner', async ({ page }) => {
  console.log('Testing Business Card Scanner...');

  await startTest(page);
  let tabVisible = await page.locator("//ul[@data-id='quickCreateLauncher']//button[@aria-label='Lead']").isVisible();
  while(!tabVisible){
    await page.locator("//button[@aria-label='Create New Record. New']").click();
    await page.waitForTimeout(2000);
    tabVisible = await page.locator("//ul[@data-id='quickCreateLauncher']//button[@aria-label='Lead']").isVisible();
  }
  await page.getByRole('menuitem', { name: 'Lead' }).click();

  await uploadAndScanCard(page, 'Business Card 4.png', 'GILBERT', 'OROZCO', 'Wholesale Director', 'Imperial PFS®', 'gilbert.orozco@ipfs.com', '210.906.4937', '', 'Dallas', 'TX');
  await uploadAndScanCard(page, 'Business Card 5.png', 'JOSH', 'LARICCIA', 'CHIEF MARKETING OFFICER', 'first insurance & risk management', 'josh.lariccia@myfirstinsurance.com', '+1 619 823 2229', '', 'San Diego', 'CA');
  await uploadAndScanCard(page, 'Business Card 10.png', 'JOHN H.', 'DAWSON', 'CHIEF FINANCIAL OFFICER', '', 'JDAWSON@CORRELLINSURANCE.COM', '864 583 5445', '859 948 3580', 'SPARTANBURG', 'SOUTH CAROLINA');
  await uploadAndScanCard(page, 'Business Card 11.png', 'Teresa', 'Boyd', 'Chief Marketing Officer', 'HUB International Florida', 'teresa.boyd@hubinternational.com', '407-893-3863', '615-415-8119', 'Winter Park', 'FL');
});
////////////////////////////////////////////////////////////////////////