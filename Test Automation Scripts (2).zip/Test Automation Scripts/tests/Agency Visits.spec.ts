import { test, expect } from '@playwright/test';
import { LoginAccess, locatorShortcuts } from '../Utils/commonVars.ts';
import { openSiteMap, advancedSearch, saveRecord, searchRecord, changeView, startTest } from '../Utils/GeneralFunctions.ts';
import { createAccount } from './Account.spec.ts';

////////////////////////////// MATT-13016 //////////////////////////////
test('Agency Visits - Notes linked to OU-Specific record', async ({ page }) => {
  console.log('Testing link to notes with OU-Specific record...');

  await startTest(page);
  
  // Create Agency Visit record
  console.log('Creating Agency Visit record...');
  
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Agency Visits').click();
  await page.getByRole('menuitem', { name: 'New', exact: true }).click();

  // Fill required data
  await page.getByRole('textbox', { name: 'Name' }).click();
  await page.getByRole('textbox', { name: 'Name' }).fill('Playwright Test Notes');
  await page.getByRole('textbox', { name: 'Name' }).press('Enter');
  await page.getByRole('button', { name: 'Search records for Primary Producer Code, Lookup field' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test For Opportunity', 'Choose producer code for');
  await page.getByRole('combobox', { name: 'Date of Start Time' }).click();
  await page.getByLabel('Date of Start Time').click();
  await page.getByRole('combobox', { name: 'Date of Start Time' }).fill('12/12/2027');
  await page.getByRole('combobox', { name: 'Date of Start Time' }).press('Enter');
  await page.getByRole('button', { name: 'Search records for Agency' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Reserved', 'Choose account for Agency');
  await page.getByRole('combobox', { name: 'Method' }).click();
  await page.getByRole('option', { name: 'In-Person' }).click();
  await page.getByRole('combobox', { name: 'Visit Type, Lookup' }).click();
  await page.getByRole('button', { name: 'Search records for Visit Type' }).click();
  await page.getByText('Thank You').click();
  await saveRecord(page);

  // Add notes to Agency Visit
  console.log('Adding notes to Agency Visit...');
  await page.getByRole('tab', { name: 'Notes', exact: true }).click();
  await page.getByRole('textbox', { name: 'Pain Points' }).click();
  await page.getByRole('textbox', { name: 'Pain Points' }).fill('Test Pain Points');
  await page.getByRole('textbox', { name: 'Growth Goals' }).click();
  await page.getByRole('textbox', { name: 'Growth Goals' }).fill('Test Growth Goals');
  await page.getByRole('textbox', { name: 'Competitive Intel' }).click();
  await page.getByRole('textbox', { name: 'Competitive Intel' }).fill('Test Competitive Intel');
  await page.locator('//section[@aria-label="Pain Points"]//input[contains(@aria-label,"Add to Agency Attributes?:")]').click();
  await page.locator('//section[@aria-label="Growth Goals"]//input[contains(@aria-label,"Add to Agency Attributes?:")]').click();
  await page.locator('//section[@aria-label="Competitive Intel"]//input[contains(@aria-label,"Add to Agency Attributes?:")]').click();
  await saveRecord(page);

  // Complete Agency Visit to update linked Account record
  console.log('Completing Agency Visit to update linked Account record...');

  await page.getByRole('menuitem', { name: 'Deactivate' }).click();
  await page.getByRole('combobox', { name: 'Status Reason' }).click();
  await page.getByRole('option', { name: 'Completed' }).click();
  await page.getByRole('button', { name: 'Deactivate' }).click();

  // Wait a few seconds for the flow to finish the execution, and then check the Account record
  await page.waitForTimeout(20000);
  console.log('Checking linked Account record...');
  await page.getByRole('tab', { name: 'Planning' }).click();
  await page.getByRole('list', { name: 'Agency Account' }).getByLabel('Playwright Test Reserved').click();
  await page.getByRole('tab', { name: 'OU-Specific' }).click();
  await expect(page.getByRole('textbox', { name: 'Pain Points' })).toHaveValue('\nTest Pain Points');
  await expect(page.getByRole('textbox', { name: 'Growth Goals' })).toHaveValue('\nTest Growth Goals');
  await expect(page.getByRole('textbox', { name: 'Competitive Intel' })).toHaveValue('\nTest Competitive Intel');

  // Clean data for future tests
  console.log('Cleaning data for future tests...');

  await page.getByRole('textbox', { name: 'Pain Points' }).click();
  await page.getByRole('textbox', { name: 'Pain Points' }).press('ControlOrMeta+a');
  await page.getByRole('textbox', { name: 'Pain Points' }).fill('');
  await page.getByRole('textbox', { name: 'Growth Goals' }).click();
  await page.getByRole('textbox', { name: 'Growth Goals' }).press('ControlOrMeta+a');
  await page.getByRole('textbox', { name: 'Growth Goals' }).fill('');
  await page.getByRole('textbox', { name: 'Competitive Intel' }).click();
  await page.getByRole('textbox', { name: 'Competitive Intel' }).press('ControlOrMeta+a');
  await page.getByRole('textbox', { name: 'Competitive Intel' }).fill('');
  await page.getByRole('menuitem', { name: 'Save & Close' }).click();

  // Wait until saving popup disappears
  await page.waitForTimeout(1500);
  await page.locator(locatorShortcuts.SAVE_LABEL).waitFor({ state: 'detached' });

  // Remove record
  await page.getByRole('menuitem', { name: 'Delete' }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();

  console.log('Test completed successfully.');
});
////////////////////////////////////////////////////////////////////////

////////////////////////////// MATT-13192 //////////////////////////////
test('Agency Visits - CRUD Operations', async ({ page }) => {
  console.log('Testing CRUD operations in Agency Visits...');

  await startTest(page, 200_000);
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Agency Visits').click();
  await page.getByRole('menuitem', { name: 'New', exact: true }).click();

  // Fill required data and check "Planning" tab fields
  console.log('Creating Agency Visit record and checking Planning tab fields...');
  await page.getByRole('textbox', { name: 'Name' }).click();
  await page.getByRole('textbox', { name: 'Name' }).fill('Playwright Test Notes');
  await page.getByRole('textbox', { name: 'Name' }).press('Enter');
  await page.getByRole('textbox', { name: 'Address' }).click();
  await page.getByRole('textbox', { name: 'Address' }).fill('Test Address');
  await page.getByRole('combobox', { name: 'Date of Start Time' }).click();
  await page.getByLabel('Date of Start Time').click();
  await page.getByRole('combobox', { name: 'Date of Start Time' }).fill('12/8/2026');
  await page.getByRole('button', { name: 'Open Duration' }).click();
  await page.getByRole('option', { name: '2 hours' }).click();
  await page.getByRole('button', { name: 'Search records for Primary Producer Code, Lookup field' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test For Opportunity', 'Choose producer code for');
  await page.getByRole('combobox', { name: 'Method' }).click();
  await expect(page.getByRole('option', { name: 'In-Person' })).toBeVisible();
  await expect(page.getByRole('option', { name: 'Virtual' })).toBeVisible();

  await page.getByRole('option', { name: 'In-Person' }).click();
  await page.getByRole('combobox', { name: 'Visit Type, Lookup' }).click();
  await page.getByRole('button', { name: 'Search records for Visit Type' }).click();
  await expect(page.getByText('Leadership')).toBeVisible();
  await expect(page.getByText('New/Re-engage')).toBeVisible();
  await expect(page.getByText('Ongoing Engagement')).toBeVisible();
  await expect(page.getByText('Thank You')).toBeVisible();

  await page.getByText('Thank You').click();
  await page.getByRole('button', { name: 'Search records for Primary Contact, Lookup field' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();

  // Choose contact and check its details
  await advancedSearch(page, 'Playwright Test Reserved', 'Choose contact for Contact');
  await expect(page.locator('//input[@aria-label="Business Phone" and @title="123456789"]')).toBeVisible();
  await expect(page.locator('//input[@aria-label="Mobile Phone" and @title="12345678"]')).toBeVisible();
  await expect(page.locator('//input[@type="email" and @title="playwright@test.com"]')).toBeVisible();
  await page.getByRole('button', { name: 'Search records for Agency' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Reserved', 'Choose account for Agency');
  await saveRecord(page);
  await page.locator('//section[@aria-label="System Information"]').getByRole('list', { name: 'Created By' }).locator('//li/div').waitFor({ state: 'visible' });

  await expect(page.locator('//ul[@title="Created By"]/li/div')).toBeVisible();
  await expect(page.locator('//input[@aria-label="Date of Created On"]')).not.toBeEmpty();
  await expect(page.locator('//input[@aria-label="Time of Created On"]')).not.toBeEmpty();
  await expect(page.locator('//ul[@title="Modified By"]/li/div')).toBeVisible();
  await expect(page.locator('//input[@aria-label="Date of Modified On"]')).not.toBeEmpty();
  await expect(page.locator('//input[@aria-label="Time of Modified On"]')).not.toBeEmpty();

  // Check "Contacts and Meeting" tab fields
  /*console.log('Filling "Contacts and Meeting" tab fields...');
  await page.getByRole('tab', { name: 'Contacts and Meeting' }).click();
  
  await page.getByRole('button', { name: 'Search records for Outlook' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  
  await page.getByRole('button', { name: 'Add new record' }).click();
  await page.getByRole('textbox', { name: 'Subject' }).click();
  await page.getByRole('textbox', { name: 'Subject' }).fill('Playwright Test Reserved');

  await page.getByRole('button', { name: 'Search records for Optional' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Producer Codes', 'Choose records for Optional');
  await page.getByRole('switch', { name: 'Teams meeting:' }).click();
  await page.getByRole('textbox', { name: 'Rich Text Editor Control' }).click();
  await page.getByRole('textbox', { name: 'Rich Text Editor Control' }).fill('Test Description');
  await page.getByRole('button', { name: 'Save and Close', exact: true }).click();
  await page.getByRole('button', { name: 'Done' }).click();

  // Check if "Meeting" record fields are saved correctly
  await expect(page.locator('//ul[@title="Required Attendees"]/li/div[@role="link"]//div[text()="Playwright Test Reserved"]')).toBeVisible();
  await expect(page.locator('//ul[@title="Optional Attendees"]/li/div[@role="link"]//div[text()="Playwright Producer Codes"]')).toBeVisible();
  await expect(page.locator('//input[@aria-label="Subject" and @value="Playwright Test Reserved"]')).toBeVisible();
  await expect(page.locator('//input[@aria-label="Location" and @value="Test Address"]')).toBeVisible();
  await expect(page.locator('//section[@aria-label="Scheduling Information"]//input[@aria-label="Date of Start Time" and @value="12/8/2026"]')).toBeVisible();
  await expect(page.locator('//section[@aria-label="Scheduling Information"]//input[@aria-label="Time of Start Time" and @value="8:00 AM"]')).toBeVisible();
  await expect(page.locator('//section[@aria-label="Scheduling Information"]//input[@aria-label="Date of End Time" and @value="12/8/2026"]')).toBeVisible();
  await expect(page.locator('//section[@aria-label="Scheduling Information"]//input[@aria-label="Time of End Time" and @value="10:00 AM"]')).toBeVisible();
  await expect(page.locator('//section[@aria-label="Scheduling Information"]//input[@aria-label="Duration" and @value="2 hours"]')).toBeVisible();
  await expect(page.locator('//section[@aria-label="Description"]//div[@data-control-name="description"]//p[contains(text(), "Test Description")]')).toBeVisible();
*/
  // Check "Notes" tab fields
  console.log('Filling "Notes" tab fields...');
  await page.getByRole('tab', { name: 'Notes', exact: true }).click();
  await page.getByRole('textbox', { name: 'Planning Notes' }).click();
  await page.getByRole('textbox', { name: 'Planning Notes' }).fill('Test Planning Notes');
  await page.getByRole('textbox', { name: 'After-Visit Notes' }).click();
  await page.getByRole('textbox', { name: 'After-Visit Notes' }).fill('After Visit Notes Testing');
  await page.getByRole('textbox', { name: 'Pain Points' }).click();
  await page.getByRole('textbox', { name: 'Pain Points' }).fill('Pair Points Testing');
  await page.getByRole('region', { name: 'Pain Points' }).getByLabel('Add to Agency Attributes?').click();
  await page.getByRole('textbox', { name: 'Growth Goals' }).click();
  await page.getByRole('textbox', { name: 'Growth Goals' }).fill('Growth Goals Testing');
  await page.getByRole('region', { name: 'Growth Goals' }).getByLabel('Add to Agency Attributes?').click();
  await page.getByRole('textbox', { name: 'Competitive Intel' }).click();
  await page.getByRole('textbox', { name: 'Competitive Intel' }).fill('Competitive Intel Testing');
  await page.getByRole('region', { name: 'Competitive Intel' }).getByLabel('Add to Agency Attributes?').click();

  // Check "Opportunities" tab fields
  console.log('Filling "Opportunities" tab fields...');
  await page.getByRole('tab', { name: 'Opportunities' }).click();
  await page.getByRole('menuitem', { name: 'Add Existing Opportunity' }).click();
  await page.getByRole('button', { name: 'Search records for Select' }).click();
  await page.getByRole('searchbox', { name: 'Select record, Multiple' }).click();
  await page.getByRole('searchbox', { name: 'Select record, Multiple' }).fill('Playwright Test Reserved');
  await page.locator('//span[text()="Playwright Test Reserved"]').first().click();
  await page.waitForTimeout(2000);
  await page.locator('//section[@aria-describedby="lookupDialogSubTitle"]').getByRole('button', { name: 'Add', exact: true }).click();
  await saveRecord(page);

  // Check "Status Reason" options for Deactivate
  console.log('Checking "Status Reason" options for Deactivate...');
  await page.getByRole('menuitem', { name: 'Deactivate' }).click();
  await page.getByRole('combobox', { name: 'Status Reason' }).click();
  await expect(page.getByRole('option', { name: 'Completed' })).toBeVisible();
  await expect(page.getByRole('option', { name: 'Canceled by Agency' })).toBeVisible();
  await expect(page.getByRole('option', { name: 'Canceled by Berkley' })).toBeVisible();
  await page.getByRole('option', { name: 'Canceled by Berkley' }).click();
  await page.getByRole('button', { name: 'Deactivate' }).click();

  // Remove record
  console.log('Removing test Agency Visit record...');
  await page.getByRole('menuitem', { name: 'Delete' }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();
});
////////////////////////////////////////////////////////////////////////

////////////////////////////// MATT-13633 //////////////////////////////
test('Agency Visits - Testing feedback from Demo 1', async ({ page }) => {
  await startTest(page);

  // Create "Agency Visit" record
  console.log('Creating "Agency Visit" record...');
  await openSiteMap(page);
  await page.locator(locatorShortcuts.SIDEMENU).getByText('Agency Visits').click();
  await page.getByRole('menuitem', { name: 'New', exact: true }).click();

  // Fill required data
  await page.getByRole('textbox', { name: 'Name' }).click();
  await page.getByRole('textbox', { name: 'Name' }).fill('Playwright Test Notes');
  await page.getByRole('textbox', { name: 'Name' }).press('Enter');
  await page.getByRole('button', { name: 'Search records for Primary Contact, Lookup field' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Reserved', 'Choose contact for Contact');
  await page.getByRole('button', { name: 'Search records for Agency' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await advancedSearch(page, 'Playwright Test Reserved', 'Choose account for Agency');
  await page.waitForTimeout(2000);
  await page.getByRole('combobox', { name: 'Method' }).click();
  await page.getByRole('option', { name: 'In-Person' }).click();
  await page.getByRole('combobox', { name: 'Visit Type, Lookup' }).click();
  await page.getByRole('button', { name: 'Search records for Visit Type' }).click();
  await page.getByText('Thank You').click();

  // Check if there are different options in "Duration" field
  console.log('Checking "Duration" field options...');
  await page.getByRole('button', { name: 'Open Duration' }).click();
  const cantOptions = await page.locator('//div[@role="listbox"]/div/div[@role="option" and contains(@data-id, "duration")]').count();
  await expect(Number(cantOptions)).toBeGreaterThan(1);
  await saveRecord(page);

  // Check if a new Meeting will have the set contact as Required Attendee
  console.log('Checking if the set contact is added as Required Attendee in new Meeting...');
  await page.getByRole('tab', { name: 'Contacts and Meeting' }).click();
  await page.getByRole('button', { name: 'Search records for Outlook' }).click();
  await page.getByRole('button', { name: 'Advanced' }).click();
  await page.getByRole('button', { name: 'Add new record' }).click();
  await expect(page.getByRole('list', { name: 'Required Attendees' }).getByRole('link', { name: 'Playwright Test Reserved' })).toBeVisible();
  await page.locator('//section[@data-id="quickCreateRoot"]//button[@data-id="quickCreateCancelBtn"]').click();
  await page.getByRole('button', { name: 'Discard changes' }).click();
  await page.getByRole('button', { name: 'Cancel' }).click();

  // Check if set contact appears in "To" field when creating a new Email from the Agency Visit record
  console.log('Checking if the set contact appears in "To" field in new Email...');

  await page.getByRole('tab', { name: 'Notes', exact: true }).click();
  await page.getByRole('button', { name: 'Create a timeline record.' }).click();
  await page.locator('//li[@role="menuitem"]').getByText('Email', { exact: true }).click();
  await page.getByText('Got it').click();
  await expect(page.getByRole('list', { name: 'To' }).getByRole('link', { name: 'Playwright Test Reserved' })).toBeVisible();
  await page.getByRole('button', { name: 'Press Enter to go back.' }).click();
  await page.getByRole('button', { name: 'Discard changes' }).click();

  // Remove record
  console.log('Removing test Agency Visit record...');
  await page.getByRole('menuitem', { name: 'Delete' }).click();
  await page.locator(locatorShortcuts.CONFIRM_BUTTON).click();
});
////////////////////////////////////////////////////////////////////////