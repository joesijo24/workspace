export enum LoginAccess {
    DYN365_ORGURL = 'https://btsuswrbppedcrmtst01.crm.dynamics.com/',
    DYN365_SalesHubAppURL = 'https://btsuswrbppedcrmtst01.crm.dynamics.com/main.aspx?appid=6e6bb233-a047-f011-877a-6045bd0a29fc',
}

export enum locatorShortcuts {
    LOADING_GRADIENT = '//div[contains(@class, "shimmerGradient")]',
    SAVE_LABEL = '//label[text()="Saving..."]',
    SIDEMENU = '//ul[@role="tree"]',
    CONFIRM_BUTTON = '//button[@data-id="confirmButton"]//div[text()="Delete"]',
}