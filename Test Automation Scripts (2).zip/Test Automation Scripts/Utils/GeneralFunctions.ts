import { Page, test } from '@playwright/test';
import { LoginAccess, locatorShortcuts } from '../Utils/commonVars.ts';

// Checks if the Site Map is open, if not, opens it
export async function openSiteMap(page: Page) {
  if(await page.locator("//button[@aria-label='Site Map']").getAttribute('aria-expanded') === 'false'){
    await page.getByRole('button', { name: 'Site Map' }).click();
  }
}

// Performs an advanced search for a record until the looked record if visible, then selects it
// name: name of the record to search for
// fieldLabel: label of the search field
export async function advancedSearch(page: Page, name: string, fieldLabel: string) {
  await page.getByRole('searchbox', { name: fieldLabel }).click();
  await page.getByRole('searchbox', { name: fieldLabel }).fill(name);
  await page.waitForTimeout(2000);

  // Checks if the record appears in the search results, if not, the search is performed again until it appears
  var focussedWindow = await page.locator('//../div[@role="dialog"]').filter({has : page.getByRole('searchbox', { name: fieldLabel })});
  var record = null;
  while(record == null){
    await page.getByRole('searchbox', { name: fieldLabel }).press('Enter');
    await page.waitForTimeout(1000);

    // Wait until loading spinner disappears
    await focussedWindow.locator('//div[contains(@class,"Spinner-circle")]').waitFor({ state: 'detached' });
    await page.waitForTimeout(1000);
    if(await focussedWindow.locator('//div[@role="gridcell"]').filter({has: page.locator('//span[text()="' + name + '"]')}).isVisible()){
      record = await focussedWindow.locator('//div[@role="gridcell"]').filter({has: page.locator('//span[text()="' + name + '"]')});
    }
  }
  
  await record.click();
  await page.locator('//../div[@role="dialog"]').filter({has : page.getByRole('searchbox', { name: fieldLabel })}).getByRole('button', { name: 'Done' }).click();
}

// Saves the current record and waits until the saving process is complete
export async function saveRecord(page: Page) {
  await page.getByRole('menuitem', { name: 'Save (CTRL+S)' }).click();

  // Wait until saving popup disappears
  await page.waitForTimeout(1500);
  await page.locator(locatorShortcuts.SAVE_LABEL).waitFor({ state: 'detached' });
}

// Searches for a record on a view using the search box and opens it
// recordName: name of the record to search for
// fieldLabel: label of the search field
export async function searchRecord(page: Page, recordName: string, fieldLabel: string, accessLink: boolean) {
  await page.getByRole('searchbox', { name: fieldLabel }).click();
  await page.getByRole('searchbox', { name: 'Apply begins with filter on' }).fill(recordName);
  await page.getByRole('searchbox', { name: 'Apply begins with filter on' }).press('Enter');

  // Wait until loading gradient bar disappears
  await page.locator(locatorShortcuts.LOADING_GRADIENT).waitFor({ state: 'detached' });
  
  if(accessLink){
    await page.getByRole('link', { name: recordName, exact : true }).click();
  }
}

// Changes the current view to the desired one
// desiredView: name of the view to switch to
export async function changeView(page: Page, desiredView: string) {
  await page.locator('//span[text()="Open popup to change view."]/..').click();
  var visible = false;
  while(!visible){
    page.waitForTimeout(1500);
    if(await page.locator('//div[@aria-label="View Options" and @role="dialog"]').isEnabled()){
      await page.locator('//ul[@aria-label="Views"]//label[text()="' + desiredView + '"]').click();
      visible = true;
    }else{
      await page.locator('//span[text()="Open popup to change view."]/..').click();
    }
  }
}

// Closes the Copilot tab if it appears upon starting a test
export async function closeCopilot(page: Page){
  var closed = false;
  const startTime = Date.now();
  const timeout = 40000; // 40 seconds timeout

  // Function waits for copilot tab to appear and closes it
  while(!closed && (Date.now() - startTime) < timeout){
    if(await page.getByRole('heading', { name: 'Copilot' }).isVisible()){
      await page.locator('//div[@aria-label="Copilot" and @role="tabpanel"]').getByTestId('close-button').click();
      closed = true;
      console.log('Copilot tab detected and closed.');
    }
  }
}

// Start function for tests
export async function startTest(page: Page, testTimeout?: number) {
  if(testTimeout){
    // Time of test set to custom value
    test.setTimeout(testTimeout);
  } else {
    // Time of test set to 2 minutes
    test.setTimeout(120_000);
  }

  // If Copilot Tab appears, it'll be closed
  //closeCopilot(page);

  // Go to main page
  await page.goto(LoginAccess.DYN365_SalesHubAppURL);
}